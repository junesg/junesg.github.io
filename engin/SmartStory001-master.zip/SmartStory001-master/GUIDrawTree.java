/*  Class: GUIDrawTree
 *
 *  Description: Class will create a drawing panel and draw the tree out based 
 *  on the tree contructed from server messages
 *
 *  Authors: (June) Yuan Shangguan D'13 and Graeson McMahon D'15
 *  CS69 Spring2013
 */

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.IOException;
import java.util.HashMap;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;


//GUIDrawTree draws the entire tree on the given drawing JPanel
public class GUIDrawTree {
    public JScrollPane scrollPane = null;    //scrollpane reference
    public StoryContent storyContent= null;  //storycontent reference
    public TreePanel treePanel;              //tree panel is the panel on which graphics are drawn and action listeners are initiated
    private treePanelControl control;        //the action listeners and controls of the tree panel
    
    //to draw each layer of tree nodes, we keep a count of how many nodes have already be drawn
    public HashMap<Integer, Integer> nodeCountAtLayerMap = new HashMap<Integer, Integer>();
    
    //to draw each node, we keep track of the node coordinate in terms of how many unitx and unity in the world
    public HashMap<Integer,Integer> nodeCordIDMap=new HashMap<Integer,Integer>();
    
    //other constants
    public int radius = 50; //radius of the node that appears on the graphic, default value is 50
    public int unitx = 70; //width of the square enveloping each bubble
    public int unity = 70; //height of the square enveloping each bubble
    public int graphicsWidth = 1000;
    public int graphicsHeight = 1000;  
    public MyViewport viewport; //the Jviewport through we we look at the treePanel graphics
    	
    private JTextArea nodeTextArea = null; //the text area to show the text associated with a node 
    private JPanel textPanel = null; 
    private JPanel GUIDrawPanel; //overall Jpanel that is passed into the constructor
    private final int MAXNODETEXT=1000;
	private final int NEW_NODE_COUNT = 3;
	
  	/*     
	 * constructor, builds up the elements inside the overall drawing panel
	 */
	public GUIDrawTree(JPanel overallPanel, StoryContent sc) {
		
		//aliasing reference to Jpanel and storyContent
		GUIDrawPanel = overallPanel;
		storyContent = sc;
		
		//set up inside layout of the drawingPanel (Jpanel)
		treePanel = new TreePanel(); 
		
		//set up controls and action listeners
		control = new treePanelControl(treePanel);  
		treePanel.addMouseListener(control);  
        	treePanel.addMouseMotionListener(control); 
        
        	//format drawPanel 
        	GUIDrawPanel.setLayout(new GridBagLayout());
        	GUIDrawPanel.setBackground(Color.white);
        	GUIDrawPanel.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        	GUIDrawPanel.setSize(GUIDrawPanel.getWidth(), GUIDrawPanel.getHeight());
        	GridBagConstraints c = new GridBagConstraints();
        
        	//set up view port
        	viewport = new MyViewport();
	    	viewport.setView(treePanel);
	    
	    	//set up scroll panel, pack viewport into scroll panel
        	scrollPane = new JScrollPane();
        	scrollPane.setViewport(viewport);
        
        	//set up and format text panel to show node text
        	textPanel = new JPanel();
        	nodeTextArea = new JTextArea("");
        	textPanel.setLayout(new GridLayout(1,1));
        	nodeTextArea.setLineWrap(true);
        	nodeTextArea.setForeground(Color.blue);
		nodeTextArea.setBackground(Color.white);
		nodeTextArea.setEnabled(true);
		textPanel.add(nodeTextArea);
		
		//Append each element of the GUIDrawPanel
		//first,add scrollPane that shows the viewport which shows parts of the graphics
        	c.gridx = 0;
        	c.gridy = 0;
        	c.weightx = 3;
        	c.weighty = 40;
       		c.fill= GridBagConstraints.BOTH;
        	GUIDrawPanel.add(scrollPane,c);
        
        	//second, add text panel that shows the text to the nodes.
        	c.gridy = 8;
        	c.weightx = 0;
        	c.weighty = 1;
        	c.anchor = GridBagConstraints.CENTER;
        	c.fill= GridBagConstraints.BOTH;
        	GUIDrawPanel.add(textPanel,c);
        	GUIDrawPanel.setVisible(true);
	}
	
	//Inner class of My viewport, which extends the typical JViewport by adding up and down half-transparent arrows to the viewport for enlarge and shrinking capabilities
    class MyViewport extends JViewport{
		/*
		 *  constructor for the JViewport, serial version ID generated for an inner class
		 */
		private static final long serialVersionUID = 1L;
		public  MyViewport() {
			this.setOpaque(true);
			this.setPreferredSize(new Dimension(GUIDrawPanel.getWidth()/2, GUIDrawPanel.getHeight()));
			this.setVisible(true);
		}
		
		//method for painting the UP and DOWN arrows on the Jviewport in order for zoom-in and zoom-out
		@Override
        	public void paint(Graphics g2) {
	       		super.paint(g2);
				Color color = new Color(0, 0,0, 0.3f); //Red 
				((Graphics2D)g2).setPaint(color);
			
			//up arrow
	       		int xpoints[] = { this.getWidth()-80, this.getWidth()-70, this.getWidth()-70, this.getWidth()-65, 
	       					this.getWidth()-75, this.getWidth()-85, this.getWidth()-80 };
	        	int ypoints[] = { 43, 43, 63, 63, 78, 63, 63 };
	        	int npoints = 7;
	        		((Graphics2D)g2).fillPolygon(xpoints, ypoints, npoints);
	        	
	        	//down arrow
	        	int xpoints2[] = { this.getWidth()-80, this.getWidth()-70, this.getWidth()-70, this.getWidth()-65, 
	        				this.getWidth()-75, this.getWidth()-85, this.getWidth()-80 };
	        	int ypoints2[] = { 41, 41, 21, 21, 6, 21, 21};
	        		((Graphics2D)g2).fillPolygon(xpoints2, ypoints2, npoints);
        }	
    }
    
	/*
	 * drawEntireTree function draws the entire tree from the start node, 
	 * it is a recursive function, and it keeps track of each layer's increasing x
	 * image index in a hashmap
	 */
	public void drawEntireTree(StoryNode topNode, int ix, int iy, Graphics g) {
	
		//if no node at the same layer has been drawn then put the node Count as zero.
		if (nodeCountAtLayerMap.get(iy) == null) {
			nodeCountAtLayerMap.put(iy, 0);
		}
		else { //if otherwise, add the node to the iy+1 position of the current layer
			nodeCountAtLayerMap.put(iy, nodeCountAtLayerMap.get(iy) + 1);
		}
		
		//draw that node at the legal position
		drawNode(radius, ( nodeCountAtLayerMap.get(iy))*unitx, iy*unity, topNode,g);
		
    		int width = graphicsWidth;
    		int indexBox = (int) nodeCountAtLayerMap.get(iy) + iy*width/unitx;
    	
    		//put the ID of the node into the nodeCordIDMap that uses the coordinate of the node as key
    		nodeCordIDMap.put(indexBox, Integer.parseInt(topNode.getText()));
		viewport.repaint();
		
		//if the top node is not empty, then we draw the entire tree and we also draw the lines between the nodes
		if (topNode.getChildren()!= null) {
			for(int i = 0; i < topNode.getNumChildren(); i++) {
				drawEntireTree(topNode.getChild(i), i, iy+1, g);
				g.setColor(Color.black);
				((Graphics2D) g).setStroke(new BasicStroke(2));
				g.drawLine(nodeCountAtLayerMap.get(iy)*unitx+radius/2, iy*unity+radius/2, 	
							(nodeCountAtLayerMap.get(iy+1))*unitx+radius/2, (iy+1)*unity+radius/2);
			}
		}
	}
	
	
	
	/*
	 * drawNode function draws a node on the graphics given at x and y given position with given radius r.
	 */
	public void drawNode(int radius, int xPos, int yPos, StoryNode node,Graphics g) {
		//first declare graphics as graphics2d
		Graphics2D g2 = (Graphics2D)g;
		
		//define x-Position(in window pixel) and y-position(window pixel) of the bubbles to draw
		Ellipse2D.Double circle;
		int currentRadius = radius;
		if (storyContent.nodeCount - node.getIndex() <= NEW_NODE_COUNT) {
			currentRadius =  (int) (1.6 * radius);
			xPos = (int) (xPos - .3 * radius);
			yPos = (int) (yPos - .3 * radius);
		}
		
		//draw the circle
		circle = new Ellipse2D.Double(xPos, yPos, currentRadius, currentRadius);
		g2.setColor(node.nodeColor);
		g2.fill(circle);
		
		//draw outline of the circle width=4, color=black
		g2.setStroke(new BasicStroke(4));
		g2.setColor(Color.black);
		g.drawOval(xPos, yPos, currentRadius, currentRadius);
	}
	
	
	//inner class for the TreePanel on which the whole graphics will be drawn
	class TreePanel extends JPanel  
	{  
		private static final long serialVersionUID = 1L;
        	public StoryNode top;
        	public Dimension area;  
        	public JPanel drawingPane;
        	public Graphics g;
        
        	//constructor for the TreePanel, sets up size
		public TreePanel()  
		{  
			area = new Dimension(0,0);
			this.setPreferredSize(new Dimension(graphicsWidth,graphicsHeight));
			if (storyContent.startNode!=null)
				repaint();
		}  
        
		//The paint function of the panel
		@Override
		protected void paintComponent(Graphics g)  
		{  
			super.paintComponent(g); 
			if (storyContent.startNode!=null) { //Check if storycontent has already been filled in
				
				//first clear the graphics where it is drawn
				g.clearRect(0, 0, getWidth(), getHeight() );
				nodeCountAtLayerMap.clear();//clear the map 
				nodeCountAtLayerMap.clear();//Clear node - layer map to start a new map later
				
				//Configure graphics
				((Graphics2D)g).setRenderingHint(RenderingHints.KEY_INTERPOLATION,  
												 RenderingHints.VALUE_INTERPOLATION_BICUBIC);  
				((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING,  
												 RenderingHints.VALUE_ANTIALIAS_ON);
				
				//first we calculate the new graphics width and height and if necessary, expand the graphics to draw all nodes
				if (storyContent.startNode != null && storyContent.startNode.getNumChildren()!=0) {
					graphicsHeight = (storyContent.startNode.getRank()+2)*unity;
					graphicsWidth = (storyContent.startNode.getWidth()+2)*unitx;
					this.setPreferredSize(new Dimension(graphicsWidth, graphicsHeight));//then we expand the current graphics size to accommodate the latest growth of the tree
					g = g.create(0,0,graphicsWidth,graphicsHeight);
					viewport.revalidate();
				}
				//We draw the entire tree on the graphics
				drawEntireTree(storyContent.startNode, 0,0,g);
			}
		} 
	}  
	
	
	//This treePanelControl Class stores all mouse controls inside the treePanel
    class treePanelControl extends MouseInputAdapter 
    {  
        public TreePanel treePanel;  
        public Point offset;  
        public boolean dragging;  
        public Dimension area = null;
        public Rectangle rect;
        public Point pressPoint,releasePoint;
		
        //Constructor for tree panel by aliasing the map
        public treePanelControl(TreePanel mp)  
        {  
            treePanel = mp;  
            offset = new Point();  
            dragging = false;  
        }  
        
        //mouseMoved event listener
        public void mouseMoved(MouseEvent e) {
        	Point p = e.getPoint();
        	int width = graphicsWidth;
        	
        	//First convert to Coordinate index of nodes
        	int ix = (int) p.x/unitx;
        	int iy = (int) p.y/unity;
        	width = graphicsWidth;
        	
        	//calculate the index of the node 
        	int indexBox = (int) ix + iy*width/unitx;
        	int NodeID = 0;
        	
        	//check the node's ID based on nodeCordinate to ID map
        	if (!nodeCordIDMap.isEmpty()) {
        		if (nodeCordIDMap.get(indexBox)!= null)
	        		NodeID = nodeCordIDMap.get(indexBox);
				
				//when moved to a node, the client sends information with the node ID to the server
	        	storyContent.out.println("GETNODETEXT"+ NodeID);
	        	
	        	//the client then listens to the user for node text line feedback
	        	try {	
	        		String NodeText = (storyContent.in.readLine());
	        		if(NodeText.length() <= MAXNODETEXT );        		
	        		else {
	        			NodeText = NodeText.substring(0, MAXNODETEXT);
	        		}
	        		nodeTextArea.setText(NodeText);
	        		textPanel.revalidate();
	        	}
	        	catch (IOException err) {
	        		err.printStackTrace();
	        	}
        	}
        }
        
        
        
        
        /*
         * Within mouseclicked action in the drawing graphics, two things might happen
         * Either the user wants to click to enlarge the graphics or shrinks it
         * Or the user wants to click a node to go to that node
         */
        public void mouseClicked(MouseEvent e) {
        	Point p = e.getPoint();
        	Point p2 = viewport.getViewPosition();
        	int width = viewport.getWidth();
        	
        	//When the user wants to enlarge the graphics
        	if (p.x > p2.x + width-80 && p.x < p2.x + width-65 && p.y > p2.y + 6 && p.y < p2.y + 41 ) {
        		//Check if the graphics is already too big 
        		if (unitx < 400 && unity < 400 && radius < 400) {
        			unitx += 5; 
        			unity += 5;
        			radius += 5;
        		}
        	}
        	
        	//When the user wants to shrink the graphics
        	else if (p.x > p2.x + width-80 && p.x < p2.x + width-65 && p.y > p2.y + 43 && p.y < p2.y + 78 ){
        		//Check if the graphics is already too small
        		if (unitx > 5 && unity >5  && radius >5) {
        			unitx -= 5; 
        			unity -= 5;
        			radius -= 5;
        		}
        	}
        	
        	//When the user wants to go to that node	
        	else {
        		//First convert to Coordinate index of nodes
	        	int ix = (int) p.x/unitx;
	        	int iy = (int) p.y/unity;
	        	width = graphicsWidth;
	        	
	        	//calculate the index of the node 
	        	int indexBox = (int) ix + iy*width/unitx;
	        	
	        	//check the node's ID based on nodeCordinate to ID map
	        	if (!nodeCordIDMap.isEmpty()) {
		        	int NodeID = nodeCordIDMap.get(indexBox);
		        	storyContent.out.println("GOTONODE"+NodeID);
		        	
		        	//sends the node ID to the server
		        	String response = "";
		        	try {	
		        		response = (storyContent.in.readLine());
		        		String[] responseSplit = response.split("@@@@");
		        		
		        		if (NodeID != 0) {
		        			storyContent.guiControl.setNavigationButtonsEnabled(true);
		        		}
		        		else {
		        			storyContent.guiControl.setNavigationButtonsEnabled(false);	
		        		}
		        		storyContent.guiControl.textArea.setText(responseSplit[0]);
		        		storyContent.guiControl.redoButtons(responseSplit[1]);		
		        		
		        	}	
		        	catch (IOException excep) {
		        		excep.printStackTrace();
		        	}
	        	}
        	}
        }
		
    } 
}
