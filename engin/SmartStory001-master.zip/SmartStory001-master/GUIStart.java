/* Class: GUIStart
 * Description: GUIStart is the user interface for servers and clients alike.
 * 				It contains the main function of the program.
 * 				Users will have the choice of choosing whether they are hosting or acting as the server.
 * 				They can establish connection when going into the Menu section
 * Author: (June) Yuan Shangguan D'13 and Graeson McMahon D'15
 * CS69 Spring2013
 */

import javax.swing.*;

public class GUIStart {
	
	private static final int WINDOWWIDTH = 1200;
	private static final int WINDOWHEIGHT = 800;
	private static StoryContent storyContent = null;
	private static GUIControlPanel guiControl = null;
	
	/* main function, sets up the whole window	 */
	public static void main (String[] args){
		JFrame topWindow = welcomeWindow();
		topWindow.setVisible(true);
	}
	
	
	/* Window function, connects the guiControlPanel, 
	 * the menu, the StoryContent(server or client socket)
	 * and the window together. 
	 */
	public static JFrame welcomeWindow(){
		JFrame window = new JFrame("Welcome to Colloborative Writing!");
		window.setSize(WINDOWWIDTH, WINDOWHEIGHT);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
		guiControl = new GUIControlPanel(window);
		storyContent = new StoryContent(guiControl);
		guiControl.linkWithStoryContent(storyContent);
		@SuppressWarnings("unused")
		GUIMenu menu = new GUIMenu(guiControl, window, storyContent);  //set up the menu of the window
		return window;
	}
	
}