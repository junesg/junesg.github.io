/*
 * Class: GUIControlPanel
 *
 * This Class sets up the overall control panel of the window,
 * including the tree-drawing graphics panel, the control buttons, the text fields etc
 * 
 * Author: June Yuan Shangguan and Graeson McMahon SmartStory CS69
 */

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import javax.swing.*;
import javax.swing.Timer;


/* 
 * GUI for drawing and controlling 
 */
public class GUIControlPanel {
	// Codes used to delineate certain locations in responses sent to client
  	static String CODE = "#&&";
  	static String CODE2 = "&&#";
  	static String CODE3 = "@@@@";
	
	// Constants
	private final int NUM_CONTINUATIONS_BEST = 4;
	private final int MAX_ENTRY_LENGTH = 1000;
	private final int DELAY = 100;
	
	// Private variables
	private StoryContent storyContent = null;
	private JPanel overallPanel = null;
	private JPanel drawingPanel = null;
	private JPanel controlPanel = null;
	private JScrollPane storySummary = null;
	private JTextField userInput = null;
	
	// Public variables
	public static final EventObject event = null;
	public Timer refreshTimer = new Timer(DELAY, new TimerListener());
	public JLabel prompt = new JLabel("How would you like to start your story?");
	public JButton endButton = new JButton("THE END");
	public JButton backButton = new JButton("Back");
	public JButton returnToStartButton = new JButton("Return to Start");
	public JTextArea textArea = null;
	public JFrame window;
	public GUIDrawTree drawTreePane = null;
	public JPanel bottomPanel = null;
	public JPanel otherContinuationsPanel = null;
	
	// Array lists for keeping track of buttons, extra buttons
	public ArrayList<ContinuationButton> contButtonList = new ArrayList<ContinuationButton>();
	public ArrayList<ContinuationButton> extraContButtonList = new ArrayList<ContinuationButton>();
	
	
	// Constructor for GUIControlPanel 
	public GUIControlPanel(JFrame awindow) {
		window = awindow;
		
		//set up overall panel 
		overallPanel = new JPanel(new GridLayout(1,2));
		overallPanel.setSize(window.getWidth(), window.getHeight());
		
		//set up drawing panel and control panel
		drawingPanel = new JPanel(new GridLayout(1,1));
		controlPanel = setUpControlPanel(); 
		storyContent = new StoryContent(this); //set up storyContent and connect that to this control panel
		drawingPanel.setSize(overallPanel.getWidth()/2, overallPanel.getHeight());
		overallPanel.add(drawingPanel);
		
		//set up drawing panel
		drawTreePane = new GUIDrawTree(drawingPanel,storyContent);
		overallPanel.add(controlPanel);
		window.add(overallPanel);
	}
	
	// Sets the storyContent variable to the given StoryContent reference
	public void linkWithStoryContent(StoryContent aStoryContent){
		storyContent = aStoryContent;
	}
	
	// Sets up the overal control panel
	private JPanel setUpControlPanel() {
		// Initialize the top panel container 
		controlPanel = new JPanel();
		
		// Contents of the top right continuation panel 
		otherContinuationsPanel = new JPanel();
		
		// Bottom area of the right hand size  panel
		JPanel overallBottom = new JPanel(new GridLayout(1,2));
		bottomPanel = new JPanel();
		bottomPanel.setLayout(new GridLayout(7, 1));
		
		//Story continuation panel
		JLabel prompt = new JLabel("How would you like to start your story?");
	    	prompt.setForeground(Color.black);
	    	prompt.setBorder(BorderFactory.createLineBorder(Color.black));
		bottomPanel.setBackground(Color.white);
		bottomPanel.add(prompt);
		userInput = new JTextField(4000);
		userInput.addActionListener(new TextEntryListener());
		bottomPanel.add(userInput);
		
		// Area for entering text to the current story
		textArea = new JTextArea("");
		textArea.setWrapStyleWord(true);
		storySummary = new JScrollPane(textArea);
		storySummary.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		storySummary.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		
		// Top panel area of the control panel
		JPanel summaryPanel = new JPanel();
		summaryPanel.setLayout(new GridLayout(1, 1));
		prompt.setForeground(Color.red);
		textArea.setLineWrap(true);
		textArea.setForeground(Color.blue);
		textArea.setBackground(Color.white);
		textArea.setEnabled(false);
		summaryPanel.add(storySummary);
		
		// Layout the grid for the top **/
		JPanel TopPanel = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		
		// Count for continuations buttons
		for (int i = 0; i < NUM_CONTINUATIONS_BEST; i++) {
			ContinuationButton newButton = new ContinuationButton();
			((ContinuationButton) newButton).setCode(i);
			newButton.addActionListener(new ContinuationButtonListener());
			contButtonList.add(i,newButton);
			bottomPanel.add(newButton);
		}
		
		// Set up the ending button
		endButton.addActionListener(new EndButtonListener());
		bottomPanel.add(endButton);
		
		// Set up the options buttons where users click to select which action to take
		JPanel optionsPanel = new JPanel(new GridLayout());
		optionsPanel.setBackground(Color.white);
		optionsPanel.setLayout(new GridLayout(8, 1));
		JLabel optionLabel=new JLabel("Options:       ");
		optionLabel.setForeground(Color.white);
		optionLabel.setForeground(Color.black);
		optionsPanel.add(optionLabel);
		
		// Display top rated story button
		JButton showBestStoryButton=new JButton("Display Top-Rated Story");
		showBestStoryButton.addActionListener(new BestStoryListener());
		optionsPanel.add(showBestStoryButton);
		
		// Display random story button
		JButton showRandomStoryButton =new JButton("Display Random Story");
		showRandomStoryButton.addActionListener(new RandomStoryListener());
		optionsPanel.add(showRandomStoryButton);
		
		// Return to the start of the story button
		returnToStartButton.addActionListener(new ReturnToStartListener());
		optionsPanel.add(returnToStartButton);
		
		// Export the story to any selected file button
		JButton exportButton =          
		new JButton("Export Storylines");
		exportButton.addActionListener(new ExportListener());
		optionsPanel.add(exportButton);
		
		// Import story from selected file button
		JButton importButton =          
		new JButton("Import Storylines");
		importButton.addActionListener(new ImportListener());
		optionsPanel.add(importButton);
		
		// Move to parent node button
		backButton.addActionListener(new BackListener());
		optionsPanel.add(backButton);
		setNavigationButtonsEnabled(false);
		
		// Set the size of optionsPanel
		optionsPanel.setSize(window.getWidth()/9, window.getHeight());
		
		otherContinuationsPanel.setLayout(new GridLayout(100, 1));
		otherContinuationsPanel.setBackground(Color.white);
		JScrollPane scrollPane = new JScrollPane(otherContinuationsPanel);
		JLabel otherContinuationsLabel = new JLabel("Other available lines:");
		otherContinuationsLabel.setForeground(Color.black);
		
		// Allow the continuationsPanel to scroll
		scrollPane.setColumnHeaderView(otherContinuationsLabel);
		scrollPane.getColumnHeader().setBackground(Color.white);
		
		// Add bottom panel to the overall panel
		overallBottom.add(bottomPanel);
		overallBottom.add(scrollPane);
		c.gridx = 0; c.gridy =0;
		c.gridwidth = 1; c.gridheight = 1;
		c.fill= GridBagConstraints.BOTH;
		c.weightx = 60.0; c.weighty = 1.0;
		
		// Add the summarypanel to the upper level of the bottom panel
		TopPanel.add(summaryPanel,c);
		c.gridx = 1;c.gridy = 0;
		c.gridwidth = 1; c.gridheight = 1;
		c.fill= GridBagConstraints.VERTICAL;
		c.weightx = 1.0; c.weighty = 1.0;
		
		// Add the optionspnael to the left hand side of the top panel
		TopPanel.add(optionsPanel,c);
		controlPanel.setLayout(new GridLayout(2, 1));
		controlPanel.add(TopPanel);
		controlPanel.add(overallBottom);
		controlPanel.setVisible(true);
		textArea.setSize(summaryPanel.getWidth(), summaryPanel.getHeight());
		return controlPanel;
	}
	
	// Defines the behavior of ContinuationButtons, which allows the user to
	// move to the specified line of the story.
	private class ContinuationButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			ContinuationButton source = ((ContinuationButton) event.getSource());
			int code = source.getCode();
			if (code != -1) {
				prompt.setText("How would you like to continue your story?");
				prompt.setBorder(BorderFactory.createLineBorder(Color.black));
				setNavigationButtonsEnabled(true);
				
				storyContent.out.println("CONTINUE" + code);
				textArea.append(source.getText());
				try {
					redoButtons(storyContent.in.readLine()); 
				}
				catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	// Defines the ContinuationButton class, an extension of the JButton class;
	// allows us to tag buttons with an ID # corresponding to a specific child
	// of the current node
	private class ContinuationButton extends JButton {
		private static final long serialVersionUID = 1L;
		private int button_code;
		public void setCode(int code) {
			button_code = code;
		}
		public int getCode() {
			return button_code; 
		}
	}
	
	// Defines the behavior of the endButton, which moves the user back to the starting node
	// and informs the server that the user though the current node was a good ending place.
	private class EndButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			prompt.setText("How would you like to start your story?");
			prompt.setBorder(BorderFactory.createLineBorder(Color.black));
			setNavigationButtonsEnabled(false);
			textArea.setText("");
			storyContent.out.println("END");
			try {
				redoButtons(storyContent.in.readLine()); 
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	// Defines the behavior of the showBestStoryButton, which moves the user to
	// the end of the top-rated story through the CURRENT line.
	private class BestStoryListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			textArea.setText("");
			storyContent.out.println("BEST");
			try {
				String storyLines = storyContent.in.readLine();
				System.out.println(storyLines);
				String[] storyParsed = storyLines.split(CODE3);
				textArea.append(storyParsed[0]);
				if (storyParsed[0].trim().compareTo("") != 0) {
					prompt.setText("How would you like to continue your story?");
					setNavigationButtonsEnabled(true);
				}
				redoButtons(storyParsed[1]); 
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	// Defines the behavior of the refreshTimer, which frequently requests updates to 
	// the client's information regarding the current node and the overall structure of
	// the tree.
	private class TimerListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			storyContent.out.println("REFRESH");
			try {
				String response = storyContent.in.readLine();
				String[] responseSplit = response.split(CODE2);
				
				if (responseSplit[2].trim() != "")
					redoButtons(responseSplit[2]);
				else
					redoButtons("");
				
				String[] authorNames = storyContent.namesToColorMap.keySet().toArray(new String[0]);
				String allAuthorNames = "";
				for (int ind = 0; ind < authorNames.length; ind ++ ){
					allAuthorNames += authorNames[ind];
					if (ind <  authorNames.length-1)
						allAuthorNames+=",";
				}
				
				storyContent.out.println("AUTHORSOFINTERESTS"+allAuthorNames);
				String authorNodeInfo = storyContent.in.readLine();
				
				if (authorNodeInfo.compareTo("") != 0) {
					setUpNodeAuthorMap(authorNodeInfo); 
				}
				storyContent.constructTree(responseSplit[0],responseSplit[1]);
				drawTreePane.treePanel.repaint();
				
			}
			catch (IOException err) {
				err.printStackTrace();
			}		
		}
	}
	
	// Defines the behavior of the showRandomStoryButton, which moves the user to
	// the end of a random story through the CURRENT line.
	private class RandomStoryListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			textArea.setText("");
			storyContent.out.println("RANDOM");
			try {
				String storyLines = storyContent.in.readLine();
				textArea.append(storyLines);
				
				if (textArea.getText().trim().compareTo("") != 0) {
					prompt.setText("How would you like to continue your story?");
					setNavigationButtonsEnabled(true);
				}
				
				redoButtons("");
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	// Defines the behavior of the returnToStartButton, which returns the user
	// to starting node.
	private class ReturnToStartListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			prompt.setText("How would you like to start your story?");
			setNavigationButtonsEnabled(false);
			textArea.setText("");
			storyContent.out.println("START");
			try {
				redoButtons(storyContent.in.readLine());
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	// Defines the behavior of the JTextFiled userInput, which allows the user
	// to create a new continuation of the current line and moves the user
	// to the newly created node.
	private class TextEntryListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			JTextField source = (JTextField) event.getSource();
			int entryLength = source.getText().trim().length();
			
			if (entryLength >= 1 && entryLength <= MAX_ENTRY_LENGTH) {
				prompt.setText("How would you like to continue your story?");
				setNavigationButtonsEnabled(true);
				
				String text = source.getText();
				storyContent.out.println("NEWLINE" + text);
				
				try {
					storyContent.in.readLine();
					redoButtons("");
				}
				catch (IOException e) {
					e.printStackTrace();
				}
				
				textArea.append(text + " ");
				source.setText("");
			}
			else {
				JOptionPane.showMessageDialog(null, "Please input a line between 1 and " 
								+ MAX_ENTRY_LENGTH + " characters long.");
			}
			
		}
	}
	
	// Defines the behavior of the exportButton, which allows the user to export
	// all information describing the current tree to a .txt file.
	private class ExportListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			storyContent.out.println("EXPORT");
			
			try {
		  	  	StoryNode.writeToFileString
		  	  	(storyContent.in.readLine().replaceAll(CODE, "\n"), getFilePath());
			}
			catch (IOException e) {
				e.printStackTrace();
			}
			
		}
	}
	
	// Defines the behavior of the importButton, which allows the user to import
	// tree information from a .txt file previously exported by the application;
	// this info is sent to the server to rebuild the tree.
	private class ImportListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			try {
				String filePath = getFilePath();
				
				if (filePath.endsWith(".txt")) {
					textArea.setText("");
					String fileText = StoryNode.getTextFromFile(filePath);
					
					if (fileText != null) {
						storyContent.out.println("IMPORT" + fileText);
						redoButtons(storyContent.in.readLine());
						prompt.setText("How would you like to start your story?");
						setNavigationButtonsEnabled(false);
					}
					else {
						JOptionPane.showMessageDialog(null, 
						"Invalid input, please use a .txt file which was exported by the program.");
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "Only .txt files can be imported.");
				}
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	// Defines the behavior of the backButton, which moves the user to the parent
	// of the current node.
	private class BackListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			storyContent.out.println("BACK");
			
			try {
				String response = storyContent.in.readLine();
				String[] responseSplit = response.split(CODE2);
				String temp = textArea.getText();
				textArea.setText(temp.substring(0, temp.length() - Integer.valueOf(responseSplit[0])));
				
				if (textArea.getText().trim().compareTo("") == 0) {
					prompt.setText("How would you like to start your story?");
					setNavigationButtonsEnabled(false);
				}
				
				redoButtons(responseSplit[1]);
			}
			catch (IOException err) {
				err.printStackTrace();
			}
		}
	}
	
	/**
	 * Puts up a fileChooser and gets path name for file to be opened.
	 * Returns an empty string if the user clicks "cancel".
	 * @return path name of the file chosen	
	 * @author Scot Drysdale
	 */
	public static String getFilePath() {
		//Create a file chooser
		JFileChooser fc = new JFileChooser();
		
		int returnVal = fc.showOpenDialog(null);
		if(returnVal == JFileChooser.APPROVE_OPTION)  {
			File file = fc.getSelectedFile();
			String pathName = file.getAbsolutePath();
			return pathName;
		}
		else
			return "";
	}
	
	// Given a String containing a series of story lines, each separated by CODE, populates
	// the ContinuationButtons with each line and sets the buttons' codes appropriately.
	public void redoButtons(String storyLines) throws IOException {
		System.out.println(storyLines);
		String[] parsedLines = storyLines.split(CODE);
		
		int i = 0;
		for (; i < parsedLines.length && i < NUM_CONTINUATIONS_BEST; i++) {
			contButtonList.get(i).setText(parsedLines[i]);
			contButtonList.get(i).setToolTipText(parsedLines[i]);
			contButtonList.get(i).setCode(i);
		}
		
		for (int j = 0; j < extraContButtonList.size(); j++) {
			extraContButtonList.get(j).setVisible(false);
		}
		
		for (; i < parsedLines.length; i++) {
			if (i - NUM_CONTINUATIONS_BEST >= extraContButtonList.size()) {
				ContinuationButton newButton = new ContinuationButton();
				((ContinuationButton) newButton).setCode(i);
				newButton.setHorizontalAlignment(SwingConstants.LEFT);
				newButton.addActionListener(new ContinuationButtonListener());
				newButton.setText(parsedLines[i]);
				newButton.setToolTipText(parsedLines[i]);
				extraContButtonList.add(newButton);
				otherContinuationsPanel.add(newButton);
			}
			else {
				extraContButtonList.get(i - NUM_CONTINUATIONS_BEST).setVisible(true);
				extraContButtonList.get(i - NUM_CONTINUATIONS_BEST).setText(parsedLines[i]);
			}
		}
		for(; i < NUM_CONTINUATIONS_BEST; i++) {
			contButtonList.get(i).setText("");
			contButtonList.get(i).setCode(-1);
		}
		if (storyLines.trim().compareTo("") == 0) {
			contButtonList.get(0).setCode(-1);
		}
	}
	
	// Given a String which lists authors and the nodes belonging to them,
	// maps each node's ID to the appropriate author.
	public void setUpNodeAuthorMap(String nodeAuthorInfo) {
		storyContent.nodeToAuthorMap.clear();
		String[] authorSplit = nodeAuthorInfo.split(CODE3);
		
		for (int i = 0; i < authorSplit.length; i++) {
			String[] authorNodeSplit = authorSplit[i].split(":");
			
			String[] nodeSplit = authorNodeSplit[1].split(",");
			
			for (int k = 0; k < nodeSplit.length; k++) {
				storyContent.nodeToAuthorMap.put(Integer.valueOf(nodeSplit[k]), authorNodeSplit[0]);
			}
		}
	}
	
	// Disables or enables buttons which are used to move backwards in the story.
	public void setNavigationButtonsEnabled(boolean setting) {
		endButton.setEnabled(setting);
		backButton.setEnabled(setting);
		returnToStartButton.setEnabled(setting);
	}
	
	public void modifyStoryContent(StoryContent sc) {
		storyContent  = sc;
		if (drawTreePane  != null)
			drawTreePane.storyContent = sc;
	}
}
