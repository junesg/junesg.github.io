/* Class: MultiClientServer.java
 * Description: This class can set up the server or close it. It can also establish the server connection, or return the server address
 * Author: (June) Yuan Shangguan D'13 and Graeson McMahon D'15
 * CS69 Spring2013
 */

import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.*;

public class MultiClientServer {
	public ServerSocket serverSocket = null;
	public static int maxId = 0;
	public int port;
	public String connectOutput;
	public static HashMap<Integer, ArrayList<Integer>> nodeChildMap 
	= new HashMap<Integer, ArrayList<Integer>>(); 
	public static HashMap<Integer, StoryNode> idNodeMap 
	= new HashMap<Integer, StoryNode>();
	public static HashMap<String, ArrayList<Integer>> authorNodeMap 
	= new HashMap<String, ArrayList<Integer>>();
	private static StoryNode TreeTopNode = new StoryNode("", null);
	
	
	//constructor for MultiClientServer
	public MultiClientServer(String portName) {
		TreeTopNode.setIndex(maxId);
		idNodeMap.put(maxId, TreeTopNode);
		nodeChildMap.put(maxId, new ArrayList<Integer>());
		maxId++;
		
		port = Integer.valueOf(portName);
		
		//start the server for listening first
		try {
			serverSocket = new ServerSocket(port);
			connectOutput = "Connection: " + "\n" + "Started on IP Address "+ this.getIPAddress()+ " and on port " + port;
			System.out.println( "Creative Writing Software Server Started on port " + port);
		}
		
		catch(IOException exc){
			System.err.println("Creative Writing Software Server failed to connect to port " + port);
			connectOutput = "Connection:" + "\n" +
			"Creative Writing Software Server failed to connect to port " + port;
			exc.printStackTrace();
			System.exit(-1);
		}
		
		
	}
	
	//This function will close the server
	public void MultiClientServerClose() {		
		port = 0000;
		//start the server for listening first
		try {
			serverSocket.close();
		}
		catch(IOException exc){
			System.err.println("Creative Writing Software Server failed to close " );
			exc.printStackTrace();
			System.exit(-1);
		}
	}
	
	//this function gets the IP address of the server and prints it as a string
	public String getIPAddress(){
		InetAddress ip;
		try {
			ip = InetAddress.getLocalHost();
			System.out.println("Current IP address : " + ip.getHostAddress());
			return ip.getHostAddress();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	//Sets up teh connection of the server
	public void ConnectionSetUp(){
		//start the serverMessenger thread
		ServerMessageSender serverMessenger = new ServerMessageSender();
		serverMessenger.start();
		
		//now accept and handle connection
		while(true){
			try {
				Socket socket = serverSocket.accept();//always listen
				ClientInfoPackage clientInfoPackage = new ClientInfoPackage();
				clientInfoPackage.setSocket(socket);
				//initiate the tree
				clientInfoPackage.setStoryNode(TreeTopNode);
				ClientListener ClientListener = new ClientListener(clientInfoPackage, serverMessenger);
				clientInfoPackage.connectClientListener  = ClientListener;
				clientInfoPackage.connectClientListener.start();
				//for debugging
				clientInfoPackage.setName(clientInfoPackage.name);
				serverMessenger.addClient(clientInfoPackage);
			}
			catch (Exception exc){
				exc.printStackTrace();
			}
		}
	}
}

