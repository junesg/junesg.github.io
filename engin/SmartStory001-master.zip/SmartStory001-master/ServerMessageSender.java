/* 
 * Class: ServerMessageSender.java
 * Function: stores the list of client-taskinfo pairs, extracts the task information from clients at
 * 			 each time step and runs the parser to determine the corresponding events. Then serverMessageSender will
 *           send the response of the parser to the respective client listener who requested the response.
 *
 *	Author: (June) Yuan Shangguan D'13 and Graeson McMahon D'15 
 *  CS69 Spring2013
 */

import java.util.Vector;

public class ServerMessageSender extends Thread{
	
	private Vector<ParserUpdateData> listDataPair = new Vector<ParserUpdateData>();	//listData stores all paired data of InputMessage, InputNode and InputUserName
	private Vector<ClientInfoPackage> vClient = new Vector<ClientInfoPackage>();//list of clients
	private String thisMessage = null; //a particular message to be processed at a time step
	private ClientInfoPackage thisClient = null; //an element of the ClientInfoPackage at a time step
	 
	//addClient adds a client to the list of clients
	public synchronized void addClient(ClientInfoPackage client){
		vClient.add(client);
	}
	
	//deleteClient allows the program to remove a client from the list of clients
	public synchronized void deleteClient(ClientInfoPackage client){
		int clientIndex = vClient.indexOf(client);
		if (clientIndex != -1)//if the client is in the client list
			vClient.removeElementAt(clientIndex);
	}
	
	//sendMessage will add the client and its message to be paired up and added into the list of datapairs for future processing
	public synchronized void sendMessage(ClientInfoPackage client, String aMessage){
		listDataPair.add(new ParserUpdateData(aMessage, client));
		notify();
	}
	
	//sendMessageToClient will allow the clientlistener to take the message and add it to the message queue
	public synchronized void sendMessageToClient (ClientInfoPackage client, String message) {
		client.connectClientListener.addMessageToQueue(message);
	}
	
	
	//extractInformationFromClient function takes in the first information in the queue
	//of client-taskinfo pairs and process its; after extraction, that pair is deleted from the queue
	private synchronized void extractInformationFromClient() throws InterruptedException{
		//if no information is available
		while(listDataPair.size() == 0) {
			wait();
		}		

		//extract a task information from the client-data pair list
		ParserUpdateData DataSet = (ParserUpdateData)listDataPair.get(0);
		thisMessage = DataSet.getMessage();
		thisClient = DataSet.getClient();
		
		//after getting the message, delete the data
		listDataPair.remove(0);
	}
	
	//run function executes a separate thread and processes the extracted information from the task queue 
	//and then uses the parser class to determine the response and finally sends the response out to the client who requested the response
	public void run() {
		while (true){
			//parsing, and return message
			try {
				extractInformationFromClient();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			//process the task message fromt the client and use parser to determine response
			String newParsedMessage = Parser.determineResponse(thisMessage, thisClient);
			
			//sends the response back to the client
			sendMessageToClient(thisClient, newParsedMessage);	
		}
	}
}