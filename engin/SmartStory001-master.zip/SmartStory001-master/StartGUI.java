package ServerFiles;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

import java.awt.*;

public class StartGUI {
	
	
	private static final int WINDOWWIDTH = 300;
	private static final int WINDOWHEIGHT = 300;
	
	// Connection information
	public static String hostIP = "localhost";
	public static int port = 8000;
	public static boolean isHost = true;
	
	public static void main(String args[]){
		JFrame window = welcomeWindow();
		window.add(socketPanel());
	}
	
	public static JFrame welcomeWindow(){
		JFrame window = new JFrame("Welcome to Colloborative Writing");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.getContentPane().add(socketPanel(), BorderLayout.CENTER);
		window.pack();
		window.setVisible(true);
		window.setSize(WINDOWWIDTH, WINDOWHEIGHT);
		window.setResizable(false);
		window.setLocation(300,300);
		return window;
	}
	
	public static JPanel socketPanel(){
		//JPanel pane = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		ActionListener ConnectButtonListener = null;
		
		//start the control Pane
		JPanel optionsPane = new JPanel(new GridLayout(5, 1));

		JPanel pane = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pane.add(new JLabel("Host IP:"));
		JTextField ipField = new JTextField(10); 
		ipField.setText(hostIP);
		ipField.setEditable(true);
		pane.add(ipField);
		optionsPane.add(pane);

		// Port input
		pane = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pane.add(new JLabel("Port:"));
		JTextField portField = new JTextField(10); 
		portField.setEditable(true);
		portField.setText((new Integer(port)).toString());
		pane.add(portField);
		optionsPane.add(pane);

		// Host/guest option
		ButtonGroup buttonGroup = new ButtonGroup();
		JRadioButton hostOption = new JRadioButton("Host", true);
		hostOption.setMnemonic(KeyEvent.VK_H);
		JRadioButton guestOption = new JRadioButton("Guest", false);
		guestOption.setMnemonic(KeyEvent.VK_G);
		buttonGroup.add(hostOption);
		buttonGroup.add(guestOption);
		pane = new JPanel(new GridLayout(1, 2));
		pane.add(hostOption);
		pane.add(guestOption);
		optionsPane.add(pane);

		// Connect/disconnect buttons
		JPanel buttonPane = new JPanel(new GridLayout(1, 1));
		JButton connectButton = new JButton("Connect");
		connectButton.setMnemonic(KeyEvent.VK_C);
		
		connectButton.setActionCommand("connect");
		connectButton.addActionListener(ConnectButtonListener);
		connectButton.setEnabled(true);
		buttonPane.add(connectButton);
		optionsPane.add(buttonPane);

		//creates the status bar including the IP address at the bottom of the window
		JPanel statusPanel = new JPanel();		
		statusPanel.setLayout(new BoxLayout(statusPanel, BoxLayout.X_AXIS));
		statusPanel.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		statusPanel.setPreferredSize(new Dimension(pane.getSize()));
		JLabel statusLabel = new JLabel(" STATUS:");
		statusLabel.setHorizontalAlignment(SwingConstants.LEFT);
		statusPanel.add(statusLabel);		
		statusPanel.setVisible(true);
		optionsPane.add(statusPanel);
		return optionsPane;
	}
	
	
	
	

		  
}