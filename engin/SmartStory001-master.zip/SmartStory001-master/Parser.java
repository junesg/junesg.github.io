/* Class: Parser
 *
 * Description: The Parser class is used to interpret messages sent
 * 				by clients and form the appropriate response. Its primary function
 * 				updates the client's currentNode and returns a String containing the 
 * 				text to send back to the client.
 *
 * Authors: Graeson McMahon D'15 and (June) Yuan Shangguan D'13
 * CS69 Spring2013
 */

import java.util.ArrayList;
import java.util.Random;
import java.util.Stack;

public class Parser {
    // Codes used to delineate certain locations in responses sent to client
    static String CODE = "#&&";
    static String CODE2 = "&&#";
    static String CODE3 = "@@@@";
	
    // Given the client's request as a String and information regarding the client,
    // returns the appropriate response as a String. Updates the client's currentNode and
    // the MultiClientServer's nodeIdMap and nodeChildMap when applicable/
    public static String determineResponse(String clientInput, ClientInfoPackage client) {
        String serverResponse = "";
        StoryNode currentNode = client.getStoryNode();
		
        
        // If the client has voted that the currentNode be the end of it's respective
        // branch, increment the endingVotes of that node, return the client to the starting
        // node, and sent the client the text of the start node's children.
        if (clientInput.contains("END")) {
            currentNode.incrementEndingVotes();
            while (currentNode.getParent() != null) {
                currentNode = currentNode.getParent();
            }
            serverResponse = concatChildText(currentNode);
        }
        
        // If the client has requested to go back one layer, send the client the length of
        // the current node's text (so that they can delete the node's text from the story)
        // and the text of the parent node's children.
        else if (clientInput.contains("BACK")) {
            serverResponse += (currentNode.getText().length() + 1) + CODE2;
            currentNode = currentNode.getParent();
            serverResponse += concatChildText(currentNode);
        }
        
        // If the client has requested the best story line through the current node, 
        // concatenate the text of the unique branch running from the start node
        // to the current node, add the text from the current node's highest rated child,
        // then move to that child and repeat until a dead-end is reached or the current node's
        // highest-rated child has a lower score than the node's endingVotes. Add the text of
        // the final node's children (if any) to the serverResponse.
        else if (clientInput.contains("BEST")) {
			serverResponse += concatStoryPathText(currentNode);     
			
            while (currentNode.getNumChildren() != 0 
				   && currentNode.getChild(0).getScore() >= currentNode.getEndingVotes()) {
                currentNode = currentNode.getChild(0);
                serverResponse += currentNode.getText() + " ";
            }
            serverResponse += CODE3 + "";    
            serverResponse += concatChildText(currentNode);        
        }
        
        // If the client requests to return to the starting node, move the currentNode 
        // to the starting node, and send the text of the starting node's children.
        else if (clientInput.contains("START")) {
            while (currentNode.getParent() != null) {
                currentNode = currentNode.getParent();
            } 
            serverResponse = concatChildText(currentNode);
        }
        
        // If the client requests to import story lines, build a tree from the text sent by
        // the client and attach it to the current tree. Update the idNodeMap and nodeChildMap
        // accordingly. Moves the client to the starting node. 
        else if (clientInput.contains("IMPORT")) {
            StoryNode temp = StoryNode.generateTreeFromFile(clientInput.substring(6));
            
            while (currentNode.getParent() != null) {
                currentNode = currentNode.getParent();
            }
            for (int i = 0; i < temp.getNumChildren(); i++) {
                currentNode.addChild(temp.getChild(i));
                temp.getChild(i).setParent(currentNode);
            }
            
            Stack<StoryNode> nodeStack = new Stack<StoryNode>();
            nodeStack.push(temp);
            
            
            // Updates idNodeMap and nodeChildMap.
            while(!nodeStack.isEmpty()) {
                StoryNode tempNode = nodeStack.pop();
                
                if (tempNode.getParent() != null) {
                    MultiClientServer.idNodeMap.put(tempNode.getIndex(), tempNode);
                    MultiClientServer.nodeChildMap.put(tempNode.getIndex(), new ArrayList<Integer>());
                    MultiClientServer.nodeChildMap.get(tempNode.getParent()
													   .getIndex()).add(tempNode.getIndex());
                    MultiClientServer.maxId++;
                }
                
                for (int j = tempNode.getNumChildren() - 1; j >= 0; j--) {
                    nodeStack.push(tempNode.getChild(j));
                }
            }
            
            serverResponse = concatChildText(currentNode);
        }
        
        // Sends a textual representation of the tree to the client.
        else if (clientInput.contains("EXPORT")) {
            StoryNode temp = currentNode;
            while(temp.getParent() != null) {
                temp = temp.getParent();
            }
            
            serverResponse = StoryNode.generateTreeText(temp);
        }
        
        // Sends a random story through currentNode to the user; uses a similar
        // approach to sending the best story.
        else if (clientInput.contains("RANDOM")) {
			serverResponse += concatStoryPathText(currentNode); 
			
            Random generator = new Random();
            int randomIndex;
			
            while (currentNode.getNumChildren() > 0) {
                randomIndex = generator.nextInt(currentNode.getNumChildren());
                currentNode = currentNode.getChild(randomIndex);
                serverResponse += currentNode.getText() + " ";
            }    
        }
        
        
        else if(clientInput.contains("SETNAME")){
        	if (clientInput.substring(7).trim().compareTo("")!=0)
        		client.setName(clientInput.substring(7));
        	else
        		client.setName("Anon");
        }
        
        
        // Adds a submission from the user to the story; creates a new node,
        // moves the user to that nodes, and updates idNodeMap, nodeChildMap,
        // and authorNodeMap.
        else if (clientInput.contains("NEWLINE")) {
            String authorName = client.getName();
            StoryNode newNode = new StoryNode(clientInput.substring(7).trim(), currentNode);
            newNode.setAuthor(authorName);
            
            newNode.setIndex(MultiClientServer.maxId);
            MultiClientServer.idNodeMap.put(MultiClientServer.maxId, newNode);
            MultiClientServer.nodeChildMap.put(MultiClientServer.maxId, new ArrayList<Integer>());
            MultiClientServer.nodeChildMap.get(currentNode.getIndex()).add(MultiClientServer.maxId);
            
            if (MultiClientServer.authorNodeMap.get(authorName) == null) {
            	MultiClientServer.authorNodeMap.put(authorName, new ArrayList<Integer>());
            }
            MultiClientServer.authorNodeMap.get(authorName).add(MultiClientServer.maxId);
            
            MultiClientServer.maxId++;
            
            currentNode.addChild(newNode);
            currentNode = newNode;
        }
        
        // Resends the client the text of the current node's children
        // and the shape of the tree (so that any additions/changes are shared
        // with the client).
        else if (clientInput.contains("REFRESH")) {
            for (int i = 0; i < MultiClientServer.maxId; i++) {
                serverResponse += i + ":";
                
                ArrayList<Integer> temp = MultiClientServer.nodeChildMap.get(i);
                int j = 0;
                for (; j < temp.size() - 1; j++) {
                    serverResponse += temp.get(j) + ",";
                }
                if (temp.size() != 0) {
                    serverResponse += temp.get(j);
                }
                if (i != MultiClientServer.maxId - 1) {
                    serverResponse += CODE3;
                }
            }
            serverResponse += CODE2 + currentNode.getIndex() 
            		+ CODE2 + concatChildText(currentNode);
        }
        
        // Moves the client to the appropriate child of the current node 
        // (indicated by the number sent by the client) and responds with
        // the text of the new current node's children.
        else if (clientInput.contains("CONTINUE")) {
            int childCode = Integer.valueOf(clientInput.substring(8));
            currentNode = currentNode.getChild(childCode);
            currentNode.incrementScore(childCode);
            serverResponse = concatChildText(currentNode);
        }
        
        // If the client requests to go directly to a node, looks up the appropriate
        // node using the ID, returning the text of the story so far as well as the
        // text of the node's children. The client's currentNode is moved to the new node.
        else if (clientInput.contains("GOTONODE")) {
        	if (MultiClientServer.idNodeMap.get(Integer.valueOf(clientInput.substring(8))) != null) {
        		currentNode = MultiClientServer.idNodeMap.get(Integer.valueOf(clientInput.substring(8)));
        	}
        	serverResponse += concatStoryPathText(currentNode); 
        	serverResponse += CODE3 + " ";    
        	serverResponse += concatChildText(currentNode);
        }
        
        // Returns the text of a node with a certain ID.
        else if (clientInput.contains("GETNODETEXT")) {
        	int nodeId = Integer.valueOf(clientInput.substring(11));
        	System.out.println("ID: " + nodeId);
        	StoryNode temp = MultiClientServer.idNodeMap.get(nodeId);
        	System.out.println(temp.getAuthor());
        	serverResponse = temp.getText() + " (" + temp.getAuthor() + ")";
        }
        
        // Returns a listing of all authors to the user.
        else if (clientInput.contains("REQUESTAUTHORS")) {
      		String[] keySet = MultiClientServer.authorNodeMap.keySet().toArray(new String[0]);
      		for (int k = 0; k < keySet.length; k++) {
      			serverResponse += keySet[k];
      			
      			if (k != keySet.length - 1) {
      				serverResponse += ",";
      			}
      		}
        }
        
        // Given a set of authors from the user, returns a String containing each
        // author's name followed by the nodes that author created.
        else if (clientInput.contains("AUTHORSOFINTERESTS")) {
        	String[] authorNames = clientInput.substring(18).split(",");
        	
        	if (authorNames.length >= 1) {
        		for (int i = 0; i < authorNames.length; i++) {
        			if (MultiClientServer.authorNodeMap.get(authorNames[i]) != null) {
        				serverResponse += authorNames[i] + ":";
        				ArrayList<Integer> nodesCreated = MultiClientServer.authorNodeMap.get(authorNames[i]);
        				for (int k = 0; k < nodesCreated.size(); k++) {
        					serverResponse += nodesCreated.get(k);
							
        					if (k != nodesCreated.size() - 1) {
        						serverResponse += ",";
        					}
        				}
						
        				if (i != authorNames.length - 1) {
        					serverResponse += CODE3;
        				}
        			}
        		}
        	}
        }
        
        client.setStoryNode(currentNode);
        return serverResponse;
        
    }
	
    // Returns a string containing the text of a node's children, each
    // child's text separated by a delineator (CODE). Used as a helper
    //function.
    private static String concatChildText(StoryNode current) {
        String serverResponse = "";
        
        int i = 0;
        if(current.getNumChildren() != 0) {
            for (; i < current.getNumChildren() - 1; i++) {
                serverResponse += current.getChild(i).getText() + " " + CODE;
            }            
            serverResponse += current.getChild(i).getText() + " ";
        }
        else {
        	serverResponse = " ";
        }
        return serverResponse;
    }
    
    // Returns a string containing the text of the story thus far (the text
    // of each node on the path from the starting node to the currentNode).
    // Used as a helper function.
    private static String concatStoryPathText(StoryNode currentNode) {
    	String serverResponse = "";
    	ArrayList<StoryNode> parentPath = new ArrayList<StoryNode>(0);
		
		StoryNode temp = currentNode;
		while(temp.getParent() != null) {
			temp = temp.getParent();
			parentPath.add(0, temp);
		}
		for (int i = 0; i < parentPath.size(); i++) {
			serverResponse += parentPath.get(i).getText() + " ";
		}
		serverResponse += currentNode.getText() + " ";
		
		return serverResponse;
    }   
}

