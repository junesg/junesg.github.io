/* Class: ParserUpdateData
 * Description: This class wraps the message and a client together, the message belongs to the client.
 * Author: (June) Yuan Shangguan D'13 and Graeson McMahon D'15
 * CS69 Spring2013
 */

public class ParserUpdateData {
	//three pairs of Message and CurrentNode of the 
	private String pairMessage = null;    //list of messages
	private ClientInfoPackage pairClient = null; 
	
	/*constructor 
	 *add messaeg will add the message, the corresponding current Node that the client is on,
	 *and the Name of the client into the the vector
	 */
	public ParserUpdateData(String aMessage, ClientInfoPackage aclient){
		pairMessage = aMessage;
		pairClient = aclient;
		
	}
	
	public String getMessage() { 
		return pairMessage;
	}

	//returns the next immediate storyNode
	public StoryNode getNode() {
		return pairClient.getStoryNode();
	}
	
	public String getName() {
		return pairClient.getName();
	}
	
	public ClientInfoPackage getClient(){
		return pairClient;
	}
		
	public void setClient(ClientInfoPackage aclient){
		pairClient = aclient;
	}
}