SmartStory001
=============