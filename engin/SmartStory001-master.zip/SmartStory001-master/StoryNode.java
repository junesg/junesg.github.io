/* Class: StoryNode
 * Description: Class used to hold data pertaining to a single line entered by the user from a story.
 * Author: (June) Yuan Shangguan D'13 and Graeson McMahon D'15
 * CS69 Spring2013
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.awt.Color;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;

public class StoryNode {
	// Codes used for delineation 
	private static final String CODE = "#&&";
	private static final String CODE2 = "@@@@";
	private static final String CODE3 = "@#&";
	
	private int scoreCounter;                          // # of times chosen as a continuation by users
	private int continuationsNumber;                   // # of children (continuations of this line)
	private int votesForEnd;                           // # of times chosen as an ending
	private ArrayList<StoryNode> storyContinuations;   // List of this node's children
	private String nodeText;                           // The text belonging to this StoryNode
	private StoryNode parent;                          // A reference to the parent of this StoryNode
	
	private int rank;                                  // Depth of this StoryNode within the tree
	private int width;                                 // Width of the tree below this StoryNode
	private int NodeID;
	public static Color defaultColor = new Color(250,250,240);
	public static Color HighLightColor = new Color(127,255,212);	
	public Color nodeColor = null;
	private String author;
	
	// Given the text of a new StoryNode and a reference to
	// its parent, constructs a new StoryNode.
	public StoryNode(String nodeText, StoryNode parent){
		scoreCounter = 0;
		continuationsNumber = 0;
		storyContinuations = new ArrayList<StoryNode>(0);
		this.nodeText = nodeText;
		this.parent = parent;
		votesForEnd = 0;
		nodeColor = defaultColor;
		NodeID = 0;
		author = "Anon";
	}
	
	// Returns the text of a StoryNode.
	public String getText() {
		return nodeText;
	}
	
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getAuthor() {
		return author;
	}
	
	// Returns the parent of a StoryNode.
	public StoryNode getParent() {
		return parent;
	}
	// Sets the parent of a StoryNode.
	public void setParent(StoryNode parent) {
		this.parent = parent;
	}
	
	// Given the text for a new StoryNode, creates a new StoryNode
	// and adds it as a child to 'this'
	public void addChild(String childText) {
		storyContinuations.add(new StoryNode(childText, this));
		continuationsNumber++;
		
	}
	
	// Given a reference to a node, adds it as a child to 'this';
	// adjusts the node's position within storyContinuations 
	// so that the list is ordered from greatest scoreCounter
	// to smallest scoreCounter.
	public void addChild(StoryNode childNode) {
		storyContinuations.add(childNode);
		
		for (int i = storyContinuations.size(); i >= 2; i--) {
			if (storyContinuations.get(i - 1).getScore() > storyContinuations.get(i - 2).getScore()) {
				StoryNode temp = storyContinuations.get(i - 1);
				storyContinuations.set(i - 1, storyContinuations.get(i - 2));
				storyContinuations.set(i - 2, temp);
			}
		}
		
		
		continuationsNumber++;
	}
	
	// Returns the child at the given index.
	public StoryNode getChild(int childNumber) {
		return storyContinuations.get(childNumber);
	}
	// Returns the list of a node's children.
	public ArrayList<StoryNode> getChildren() {
		return storyContinuations;
	}
	// Returns the number of children a StoryNode has.
	public int getNumChildren() {
		return continuationsNumber;
	}
	
	// Increments the scoreCounter of a node, taking care
	// to adjust the node's position within the storyContinuations
	// list of it's parent (which is kept in order from highest
	// scoreCounter to lowest).
	public void incrementScore(int childNumber) {
		scoreCounter++;
		
		int i = childNumber;
		for (; i - 1 >= 0 && parent.getChild(i - 1).getScore() < getScore(); i--) {
			StoryNode temp = parent.storyContinuations.get(i - 1);
			parent.storyContinuations.set(i - 1, this);
			parent.storyContinuations.set(i, temp);
		}
	}
	
	// Returns a node's scoreCounter.
	public int getScore() {
		return scoreCounter;
	}
	
	// Sets a node's scoreCounter.
	public void setScore(int score) {
		this.scoreCounter = score;
	}
	
	// Returns a node's votesForEnd.
	public int getEndingVotes() {
		return votesForEnd;
	}
	
	// Increments a node's votesForEnd.
	public void incrementEndingVotes() {
		votesForEnd++;
	}
	
	// Sets a node's votesForEnd.
	public void setEndingVotes(int votes) {
		this.votesForEnd = votes;
	}
	
	// Creates a textual representation of a tree of StoryNodes
	// and returns it.
	public static String generateTreeText(StoryNode startNode) {
		HashMap<Integer, StoryNode> nodeMap = MultiClientServer.idNodeMap;
		String treeText = CODE3 + CODE;
		
		int j = 0;
		StoryNode current = startNode;
		while (current != null) {
			treeText += Integer.toString(j) + ":";
			int k = 0;
			for (; k < current.getNumChildren() - 1; k++) {
				treeText += current.getChild(k).getIndex() + ",";
			}
			if (current.getNumChildren() != 0) {
				treeText += current.getChild(k).getIndex();
			}
			
			treeText += CODE + current.getText();
			treeText += CODE + Integer.toString(current.getScore());
			treeText += CODE + Integer.toString(current.getEndingVotes()) + CODE;
			
			j++;
			current = nodeMap.get(j);
		}
		
		String[] keySet = MultiClientServer.authorNodeMap.keySet().toArray(new String[0]);
		for (int k = 0; k < keySet.length; k++) {
			treeText += keySet[k] + "@";
			for (int l = 0; l < MultiClientServer.authorNodeMap.get(keySet[k]).size(); l++) {
				treeText += MultiClientServer.authorNodeMap.get(keySet[k]).get(l);
				if (l != MultiClientServer.authorNodeMap.get(keySet[k]).size() - 1) {
					treeText += ",";
				}
			}
			if (k != keySet.length - 1) {
				treeText += CODE;
			}
		}
		
		return treeText;
	}
	
	// Writes the contents of storyLines to the file at fileName; used to
	// store a textual representation of a tree of StoryNodes.
	public static void writeToFileString(String storyLines, String fileName) throws IOException {
		BufferedWriter output = new BufferedWriter(new FileWriter(fileName));
		output.write(storyLines);
		output.close();
	}
	
	// Gets the text from the file at fileName, using CODE as an indication
	// of line breaks; returns the text.
	public static String getTextFromFile(String fileName) throws IOException {
		BufferedReader fileReader = new BufferedReader(new FileReader(fileName));
		String fileText = "";
		
		String line = fileReader.readLine();
		if (line.trim().compareTo(CODE3) != 0) {
			return null; 
		}
		line = fileReader.readLine();
		
		while (line != null) {
			fileText += line + CODE;
			line = fileReader.readLine();
		}
		fileReader.close();
		
		return fileText;
	}
	
	// Reads in the textual representation of a tree from a file,
	// recreates the tree, and returns it.
	public static StoryNode generateTreeFromFile(String text) {
		String[] treeLines = text.split(CODE);
		ArrayList<String> connectionLineArray = new ArrayList<String>();
		HashMap<Integer, StoryNode> nodeMap = new HashMap<Integer, StoryNode>();
		int nodeCounter = 0;
		
		int i = 0;
		while (i < treeLines.length) {
			String connectionLine = treeLines[i];
			
			if (!connectionLine.contains("@")) {
				String[] connectionSplit = connectionLine.split(":");
				connectionLineArray.add(connectionLine);
				
				String textLine = treeLines[++i].trim();
				String scoreLine = treeLines[++i];
				String endingLine = treeLines[++i];
				
				StoryNode newNode = new StoryNode(textLine, null);
				newNode.setScore(Integer.valueOf(scoreLine));
				newNode.setEndingVotes(Integer.valueOf(endingLine));
				newNode.setIndex(Integer.valueOf(connectionSplit[0]) + MultiClientServer.maxId - 1);
				
				nodeMap.put(Integer.valueOf(connectionSplit[0]), newNode);
				nodeCounter++;
			}
			else {
				String[] connectionSplit = connectionLine.split("@");
				String authorName = connectionSplit[0];
				String[] nodesOwned = connectionSplit[1].split(","); 
				
				for (int k = 0; k < nodesOwned.length; k++) {
					if (MultiClientServer.authorNodeMap.get(authorName) == null) {
						MultiClientServer.authorNodeMap.put(authorName, new ArrayList<Integer>());
					}
					MultiClientServer.authorNodeMap.get(authorName).add
					(Integer.valueOf(nodesOwned[k]) + MultiClientServer.maxId - 1);
					
					nodeMap.get(Integer.valueOf(nodesOwned[k])).setAuthor(authorName);
				}
			}
			i++;
		}
		
		for (int j = 0; j < nodeCounter; j++) {
			String currentLine = connectionLineArray.get(j);
			String[] connectionSplit = currentLine.split(":");
			
			StoryNode parentNode = nodeMap.get(j);
			
			if (connectionSplit.length > 1) {
				String[] childSplit = connectionSplit[1].split(",");
				
				for (int k = 0; k < childSplit.length; k++) {
					StoryNode child = nodeMap.get(Integer.valueOf(childSplit[k]));
					parentNode.addChild(child);
					child.setParent(parentNode);
					
				}
			}			
		}
		
		
		return nodeMap.get(0);
	}
	
	// Given text representing the shape of a tree of StoryNodes, builds
	// that tree and returns a reference to its starting node; used to
	// draw a graphical representation of the current tree.
	public static StoryNode buildEmptyTreeFromText(String treeInfo, String NodeID, 
	HashMap<Integer, String> nodeToAuthorMap, HashMap<String,Color> namesToColorMap, StoryContent storyContent) {
		
		String[] treeLines = treeInfo.split(CODE2);
		int nodeID = Integer.parseInt(NodeID);	
		ArrayList<String> connectionLineArray = new ArrayList<String>();
		HashMap<Integer, StoryNode> nodeMap = new HashMap<Integer, StoryNode>();
		
		int nodeCounter = 0;
		
		int i = 0;
		while (i < treeLines.length) {
			String connectionLine = treeLines[i];
			String[] connectionSplit = connectionLine.split(":");
			connectionLineArray.add(connectionLine);	           
			//here, we put the index of the node into the text of the node too
			StoryNode newNode = new StoryNode(connectionSplit[0], null);
			newNode.setIndex(Integer.valueOf(connectionSplit[0]));
			if(!nodeToAuthorMap.isEmpty() && !namesToColorMap.isEmpty()) {
				if (nodeToAuthorMap.get(Integer.valueOf(connectionSplit[0])) != null) {
					newNode.author = nodeToAuthorMap.get(Integer.valueOf(connectionSplit[0]));
					newNode.nodeColor = namesToColorMap.get(newNode.author);
					
				}
			}
			nodeMap.put(Integer.valueOf(connectionSplit[0]), newNode);
			nodeCounter++;
			i++;
		}
		
		for (int j = 0; j < nodeCounter; j++) {
			String currentLine = connectionLineArray.get(j);
			String[] connectionSplit = currentLine.split(":");
			
			if (connectionSplit.length > 1) {
				String[] childSplit = connectionSplit[1].split(",");
				StoryNode parentNode = nodeMap.get(j);
				for (int k = 0; k < childSplit.length; k++) {
					StoryNode child = nodeMap.get(Integer.valueOf(childSplit[k]));
					parentNode.addChild(child);
					child.setParent(parentNode);
				}
			}
		}
		
		//allows highlighted color to propagate from the current chosen node to the top node
		propagateColorToTop(StoryNode.findNode (nodeID, nodeMap.get(0)), StoryNode.HighLightColor);
		storyContent.nodeCount = nodeCounter;
		return nodeMap.get(0);
	}
	
	
	//Givens the top node of the tree and certain color,
	//makes the tree have the color from the root to the leaves
    public static void propagateColorFromTop(StoryNode startNode, Color c) {
    	startNode.nodeColor = c;
    	for (int i = 0; i < startNode.getNumChildren(); i ++) {
			propagateColorFromTop(startNode.getChild(i),  c) ;
    	}
    }
    
	//Given a current node (any node in the tree) and a certain color
	//allows the color to appear on the path from the start node to the current node
	public static void propagateColorToTop(StoryNode node, Color c) {
		node.nodeColor = c;
		if(node.getParent() != null)
			propagateColorToTop(node.getParent(),c);
	}
	
	// Gets the rank of a tree.
	// Rank of the tree is defined as the number of layers of the tree node +1
	public int getRank() {
	
		if (rank > 1);
		else {
			int i = 0;
			if (this.continuationsNumber > 0) {
				for(; i < continuationsNumber ; i ++) {
					int newRank = storyContinuations.get(i).getRank();
					if(rank < newRank+1) {
						rank = newRank+1;
					}
					else;
				}
			}
		}
		return rank;
	}
	
	// Gets the width of a StoryNode.
	// width of the tree is defined as the largest number of nodes in a layer of the tree
	public int getWidth() {
		width = 1; 		//if no child is present, width == 1
		
		//Set up comparison layers of nodes
		ArrayList<StoryNode> CurrentLayer = new ArrayList<StoryNode>();
		ArrayList<StoryNode> NextLayer = new ArrayList<StoryNode>();	
		CurrentLayer.add(this);
		
		//if another child is present, width is the summation of the number of children - 1 (current node)
		while(CurrentLayer.size() > 0) {
			for(int i =0; i< CurrentLayer.size(); i ++) {
				NextLayer.addAll(CurrentLayer.get(i).getChildren());
			}
			if (NextLayer.size() > width) {
				width = NextLayer.size();
			}
			CurrentLayer = NextLayer;
			NextLayer = new ArrayList<StoryNode>();
		}
		return width;
	}
	
	// Increases a node's rank.
	public void IncreaseRank(){
		rank = rank + 1;
	}
	
	// Increases a node's width.
	public void IncreseWidth(int k) {
		width += k;
	}
	
	// Returns the starting node of the tree of which
	// 'this' is a member.
	public StoryNode getTopNode(){
		if (parent != null) {
			return parent.getTopNode();
		}
		else
			return this;
	}
	
	//Two functiosn that gets and sets the index of a node
	public void setIndex (int ID){
		NodeID = ID;
	}
	public int getIndex () {
		return NodeID;
	}
	
	//propagate down the tree to find the node with ID as the nodeID
	public static StoryNode findNode (int ID, StoryNode startNode) {
		StoryNode indexNode = null;
		if(startNode.NodeID == ID) {
			indexNode =  startNode;
		}
		else {
			for (int i = 0 ; i < startNode.getNumChildren(); i++) {
				indexNode = findNode (ID, startNode.getChild(i));
				if (indexNode != null)
					return indexNode;
			}
		}
		return indexNode;
	}
	
}
