/* Class: ClientInfoPackage
 * 
 * Function: This class encapsulates the information related to a client, including:
 * socket adress, name, clientlistener reference and storyNode which the client is on
 * 
 * Authors: (June) Yuan Shangguan D'13 and Graeson McMahon D'15
 * CS69 Spring2013
 */

import java.net.Socket;

public class ClientInfoPackage{
	
	public String name = null;
	public ClientListener connectClientListener= null; 
	
	private Socket connectSocket = null;
	private StoryNode currentStoryNode = null ;

	// Functions setting and getting the socket reference 
	public void setSocket(Socket socket){
		connectSocket = socket;
	}
	public Socket getSocket() {
		return connectSocket;
	}
	
	// Functions relating to setting and getting of the storyNode
	public void setStoryNode(StoryNode aNode) {
		currentStoryNode = aNode;
	}
	public StoryNode getStoryNode() {
		return currentStoryNode;
	}
	
	// Functions setting and getting of the name
	public void setName (String aName) {
		name = aName;
	}
	public String getName() {
		return name;
	}
}
