/*
 * Class: ClientListener
 * 
 * This class will function by running as a thread and keeping a queue of information 
 * when info is sent from a particular client, the server adds that to the ServerMessageSender,
 * which determines the server response and sends back to the clientlistener as part of the queue.
 * Client listener then pops a message each time from a queue to process
 * 
 * Authors: June Yuan Shangguan and Graeson McMahon
 */

import java.net.*;
import java.util.Vector;
import java.io.*;

public class ClientListener extends Thread{
	
	private ServerMessageSender thisServerMessageSender;
	private ClientInfoPackage thisClient;
	private BufferedReader stringBuffer;
	private PrintWriter messageOut;
	private Vector<String> messageQueue = new Vector<String>();
	
	// Constructor, aliasing variables
	public ClientListener (ClientInfoPackage client, ServerMessageSender serverMessageSender) throws IOException {
		thisClient = client;
		thisServerMessageSender = serverMessageSender;
		Socket socket  = client.getSocket();
		stringBuffer = new BufferedReader ( new InputStreamReader (socket.getInputStream()));
		messageOut = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
	}
	
	// This function gets one message from the queue when called and returns it as a String
	private synchronized String getNextMessageFromQueue() throws IOException {
		while(messageQueue.size() == 0){
			try {
				this.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		String message = (String) messageQueue.get(0);
		messageQueue.removeElementAt(0);
		return message;
	}
	
	// This function sends out a message to the client
	private void sendMessageToClient(String aMessage){
		messageOut.println(aMessage);
		messageOut.flush();
	}
	
	// This function adds a message to the queue
	public synchronized void addMessageToQueue(String aMessage) {
		messageQueue.add(aMessage);
		notify();
	}
	
	// Main run function for a thread
	public void run(){
		try {
			while(!isInterrupted()){
				String messageIn = stringBuffer.readLine();
				if (messageIn == null)
					break;// If we ever receives an empty String, then break the while loop
				// sends the received message with the name of the client to the ServerMessageSender
				thisServerMessageSender.sendMessage(thisClient,messageIn);
				
				// Pops a message from the queue and sends it to the client
				String messageOut = getNextMessageFromQueue();
				sendMessageToClient(messageOut);
			}
		}
		catch (IOException ioex){
			System.out.println("ClientListener: message receiver is interrupted...");
		}
		// If the while loop is interrupted, then delete this client to continue 
		thisServerMessageSender.deleteClient(thisClient);
	}
	
	
}
