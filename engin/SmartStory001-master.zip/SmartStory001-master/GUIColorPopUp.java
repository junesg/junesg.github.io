/*
 * Class: GUIControlPopUp 
 *
 * This Class sets up the author-color pop-up window 
 * for user to enter select author of interests and corresponding colors 
 * 
 * Author: (June) Yuan Shangguan and Graeson McMahon SmartStory CS69
 */
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class GUIColorPopUp{
	
	// Public variables
	public String[] authors;            //List of author names
	public StoryContent storyContent;   //overall content for story
	public JDialog colorPopUp = null;	 //reference to the colorPopUp window
	public int index;
	public JLabel label = null;
	public JColorChooser tcc = null;
	public JButton confirmButton = null;
	public JFrame popUpWindow = null;
	public JButton chooseButton = null;
	
	// Arraylists of authors, panes and their checkboxes
	public ArrayList<Color> authorColors = new ArrayList<Color>();
	public ArrayList<JPanel> panes = new ArrayList<JPanel>();
	public ArrayList<JCheckBox> checkboxes = new ArrayList<JCheckBox>();
	
	// Private variables
	private final int POPUPWIDTH = 600; 
	private final int POPUPHEIGHT = 600;
	private final int OPTIONHEIGHT = 50;
	
	
	// Constructor, takes information in terms of the top window reference, the storyContent reference,
	// and a string as the title of the pop up.
	public GUIColorPopUp(JFrame TopWindow, String[] allAuthors, StoryContent astoryContent)  {
		
		// Alias references
		authors  = allAuthors;
		storyContent = astoryContent;
		int numAuthors = authors.length;
		
		// Set up the popup window display 
		colorPopUp= new JDialog();
		colorPopUp.setTitle("Choose Author of interests and select color");
		
		// Configuring Popup properties
		colorPopUp.setVisible(true);
		colorPopUp.setSize(POPUPWIDTH, POPUPHEIGHT);
		colorPopUp.setLocation(POPUPWIDTH, POPUPHEIGHT);	
		colorPopUp.setLocationRelativeTo(TopWindow);
		
		// The overall pane that holds all user names
		JPanel chooserPane = new JPanel(new GridLayout(numAuthors+1, 1));
		chooserPane.setSize(new Dimension(POPUPWIDTH, OPTIONHEIGHT*numAuthors));
		
		// Set up scroll pane to be put into the overall pane
		JScrollPane scroll = new JScrollPane(chooserPane);
		colorPopUp.add(scroll);
		scroll.setPreferredSize(chooserPane.getSize());
		
		// Loop through the panes with the names of the author
		for (index = 0; index < numAuthors; index ++ ) {
			authorColors.add(Color.GRAY);
			JPanel pane = new JPanel(new GridLayout(1,3));
			label = new JLabel();
			label.setText(authors[index]);
			label.setHorizontalAlignment(JLabel.CENTER);
			pane.add(label);
			
			// Set up button for colorpicker
			chooseButton = new JButton("Click Here to Choose Color");
			chooseButton.setForeground (Color.black);
			chooseButton.setBackground(authorColors.get(index));
			chooseButton.setVisible(true);
			chooseButton.setOpaque(true);//for mac debugging
			chooseButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(e.getSource() instanceof JButton) {
						((JButton)e.getSource()).setBackground(JColorChooser.showDialog(chooseButton, "Select a Background Color", chooseButton.getBackground()));
						((JButton)e.getSource()).revalidate();
						int ind = panes.indexOf(((JButton)e.getSource()).getParent());
						authorColors.set(ind, ((JButton)e.getSource()).getBackground());
					}
		  		}
		  	}); 
			
			pane.add(chooseButton);
			JCheckBox cb = new JCheckBox("Show Color");
			cb.setSelected(false);
			checkboxes.add(cb);
			cb.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	int ind = panes.indexOf(((JCheckBox)e.getSource()).getParent());
	            	// Check which one is chosen and sends back the information
	            	((JCheckBox)checkboxes.get(ind)).setSelected(((JCheckBox)(e.getSource())).isSelected());
	            }
	        });
			pane.add(cb);
			panes.add(pane);//add to the panes collection
			chooserPane.add(pane);
		}
		// Add the confirm button 
		JPanel pane = new JPanel(new GridLayout(1,1));
		confirmButton = new JButton("Confirm Color Setting");
		confirmButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				colorPopUp.dispose();
				storyContent.namesToColorMap = getAuthorNameColor();
	  		}
	  	}); 
		pane.add(confirmButton);
		chooserPane.add(pane);
	}
	
	
	// Function that returns the map of authors mapped to colors
	public HashMap<String,Color> getAuthorNameColor() {
		HashMap<String,Color> namesColorMap = new HashMap<String,Color>();
		for (int i = 0; i< checkboxes.size(); i++) {
			if(((JCheckBox)checkboxes.get(i)).isSelected()){
				System.out.println("in GUIColorPopUp, the "+ i + "th name-color is enabled");
				namesColorMap.put(authors[i], authorColors.get(i));
			}
			else;
		}
		return namesColorMap;
	}
}

