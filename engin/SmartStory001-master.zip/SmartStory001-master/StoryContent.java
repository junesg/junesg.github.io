/* Class: StoryNode
 *
 * Description:Class that holds all references of GUI and socket and storyNode together
 * It also extends thread to allow threading of the server/client
 *
 * Authors: June Yuan Shangguan and Graeson McMahon, SmartStory CS69
 */

import java.awt.Color;
import java.io.*;
import java.net.*;
import java.util.HashMap;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class StoryContent {
	public boolean isHost = true;
	public boolean isConnected = false;
	public String ipAddress = null;
	public String portAddress = null;
	public MultiClientServer server = null;
	public StoryNode startNode=null,  currentNode = null;
	public GUIControlPanel guiControl;
	public PrintWriter out = null;
	public BufferedReader in = null;
	public String status = null;
	public connectionSetUP Setup = null;
	//This linked StoryContent reference is only useful when there is a server running together 
	//with a client on the same computer. We register the server in this linkStoryContent.
	public StoryContent linkStoryContent = null;
	public HashMap<String,Color> namesToColorMap = new HashMap<String,Color>();
	public HashMap<Integer, String> nodeToAuthorMap = new HashMap<Integer, String>();
	public String name;
	public JTextField IPTextField = null;
	public int nodeCount;
	
	private Socket clientSocket = null;
	
	//Construction, every storycontent has to be linked to a guicontrol
	public StoryContent(GUIControlPanel aguiControl){
		guiControl = aguiControl;
		guiControl.modifyStoryContent(this);
		currentNode = new StoryNode("",null);
		Setup = new connectionSetUP(server, ipAddress, portAddress, status,name, guiControl);
	}
	
	// alternative constructor with the input as a storyContent
	public StoryContent(StoryContent content1) {
		isHost = content1.isHost;
		isConnected = content1.isConnected;
		ipAddress = content1.ipAddress;
		portAddress = content1.portAddress;
		server = content1.getServer();
		clientSocket = content1.getSocket();
		startNode = content1.startNode;
		currentNode = content1.currentNode;
		guiControl = content1.getControlPanel();
		out  = content1.out;
		in   = content1.in;
		name = content1.name;
		Setup = new connectionSetUP(server, ipAddress, portAddress, status, name, guiControl);
	}	
	
	// set up a server for the StoryContent when the guiControl is indeed a Server
	public MultiClientServer SetUpServer() {
		//if condition checks to make sure that is a server
		if (isHost && portAddress != null) {  
			server = new MultiClientServer(portAddress);
			Setup.server = server;
			return server;
		}
		else {
			System.err.println("Error: Failure to identify a Host Server.");
			return null;
		}
	}
	
	//set up connection on a server
	class connectionSetUP extends Thread{
		MultiClientServer server = null;
		GUIControlPanel guiControl = null;
		
		
		public connectionSetUP(MultiClientServer aserver, String aipAddress, String aportAddress, String astatus, String name, GUIControlPanel aguicontrol){
			server = aserver;
			guiControl = aguicontrol;
		}
		public void run(){ 
			if(isHost) {		 //if this is a server, then set up server connection
				if (server != null) {
					server.ConnectionSetUp();
					System.out.println("server is set up");
				}
				else {
					System.err.println("Error: Failure to set up connection on a Host Server");
					status  = "Error: Failure to set up connection on a Host Server";
				}
			}
			else {        //if this is a client, then set up client connection
				if (ipAddress == null || portAddress == null || isHost) {
					System.err.println("Error: Failure to set up Client connections.");
					status = "Error: Failure to set up Client connections.";
				}
				else {
					try {
						int port = Integer.parseInt(portAddress);
						clientSocket = new Socket(ipAddress, port);
						out = new PrintWriter(clientSocket.getOutputStream(), true);
						in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
						//first delay so that the user automatically updates
						if (name.length() > 20 || name.contains("#") || name.contains("@") 
								|| name.contains("&") || name.contains(":") || name.contains(",")) {
							name = "Anon";
							JOptionPane.showMessageDialog(null, "Invalid name, defaulting to: Anon");
							IPTextField.setText("Anon" + IPTextField.getText().split(",")[1]);
						}
						else if (name.trim().compareTo("") == 0) {
							name = "Anon";
							IPTextField.setText("Anon" + IPTextField.getText());
						}
						out.println("SETNAME"+name);
						in.readLine();
						guiControl.refreshTimer.setInitialDelay(0);
						//we start the timer of the guiController
						guiControl.refreshTimer.start();						
					} 
					catch (IOException e) {
						System.err.println("Error: Failure to set up Client Connections with Server address " + ipAddress + " and port "+ portAddress + "." );
						status = "Error: Failure to set up Client Connections with Server address " + ipAddress + " and port " + portAddress + ".";
						e.printStackTrace();
					}
				}
			}		
		}
		
	}
	
	public MultiClientServer getServer(){
		return server;
	}
	public Socket getSocket(){
		return clientSocket;
	}
	public GUIControlPanel getControlPanel(){
		return guiControl;
	}
	public void setControlPanel(GUIControlPanel p){
		guiControl = p;
		Setup.guiControl=p;
	}
	
	
	public void constructTree(String treeinfo, String NodeID){
		startNode = StoryNode.buildEmptyTreeFromText(treeinfo, NodeID, nodeToAuthorMap, namesToColorMap, this);
	}
	
	
}
