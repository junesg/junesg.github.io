/*  Class: GUISocket
 *
 *	GUISocket class allows a pop-up dialog to appear with text areas to be fille in,
 *	these text areas will carry essential information for socket connections
 *
 *  Authors: June Yuan Shangguan and Graeson McMahon SmartStory CS69
 */

import java.awt.*;
import java.awt.event.*;
import java.net.UnknownHostException;
import javax.swing.*;
import javax.swing.border.BevelBorder;


/* set up the socket pop-up connection window 
 * for user to enter host IP and port, and select whether they 
 * are hosts or guests
 */
public class GUISocket{
	//Popup socket size
	private final int POPUPWIDTH = 500;
	private final int POPUPHEIGHT = 300;
	//private variables
	private int connectButtonIsClicked = 0;//boolean to register user mouse click selection
	private JDialog PopUp = null;//The dialogue box that pops up
	private StoryContent storyContent = null;//Over-arching package for linking multiple GUI units together 
	private JFrame TopWindow;
	//public variables
	public static String hostIP = "localhost";// Connection information
	public static int port = 8000;
	public MultiClientServer server = null;
	
	
	
	//Constructor, takes information in terms of the top window reference, the storyContent reference,
	//and a string as the title of the pop up.
	public GUISocket(String title, JFrame window, StoryContent aStoryContent) {
		//linking information intake with variables
		storyContent = aStoryContent;
		TopWindow = window;
		PopUp = new JDialog();
		PopUp.setTitle(title);
		//Configuring Popup properties
		PopUp.setVisible(true);
		PopUp.setSize(POPUPWIDTH, POPUPHEIGHT);
		PopUp.setLocation(POPUPWIDTH, POPUPHEIGHT);	
		PopUp.setLocationRelativeTo(TopWindow);
		
		//Design the control pane
		JPanel optionsPane = new JPanel(new GridLayout(6, 1));
		PopUp.add(optionsPane);
		
		//pane is the temporary components to be added to the optionsPane
		//ipAddress input
		JPanel pane = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pane.add(new JLabel("Host IP:"));
		final JTextField ipField = new JTextField(10); 
		ipField.setText(hostIP);
		ipField.setEditable(true);
		pane.add(ipField);
		optionsPane.add(pane);
		
		// Port input
		pane = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pane.add(new JLabel("Port:"));
		final JTextField portField = new JTextField(10); 
		portField.setEditable(true);
		portField.setText((new Integer(port)).toString());
		pane.add(portField);
		optionsPane.add(pane);
		
		
		//Ask for user name
		pane = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pane.add(new JLabel("Enter Your Name:"));
		final JTextField nameField = new JTextField(50); 
		nameField.setEditable(true);
		pane.add(nameField);
		optionsPane.add(pane);
		
		
		// Host/guest option
		ButtonGroup buttonGroup = new ButtonGroup();
		final JRadioButton hostOption = new JRadioButton("Host", true);
		hostOption.setMnemonic(KeyEvent.VK_H);
		final JRadioButton guestOption = new JRadioButton("Guest", false);
		guestOption.setMnemonic(KeyEvent.VK_G);
		buttonGroup.add(hostOption);
		buttonGroup.add(guestOption);
		pane = new JPanel(new GridLayout(1, 2));
		pane.add(hostOption);
		pane.add(guestOption);
		optionsPane.add(pane);
		
		// Connect/disconnect buttons
		JPanel buttonPane = new JPanel(new GridLayout(1, 2));
	    final JButton connectButton = new JButton("Connect");
	    connectButton.setMnemonic(KeyEvent.VK_C);
	    connectButton.setActionCommand("connect");
	    connectButton.setEnabled(true);
	    final JButton disconnectButton = new JButton("Disconnect");
	   	disconnectButton.setMnemonic(KeyEvent.VK_D);
	  	disconnectButton.setActionCommand("disconnect");
		disconnectButton.setEnabled(false);
	    buttonPane.add(connectButton);
	    buttonPane.add(disconnectButton);
	    optionsPane.add(buttonPane);	    
		
	    
		//creates the status bar including the IP address at the bottom of the window
		final JPanel statusPanel = new JPanel();		
		statusPanel.setLayout(new BoxLayout(statusPanel, BoxLayout.X_AXIS));
		statusPanel.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		//statusPanel.setPreferredSize(new Dimension(pane.getSize()));
		final JLabel statusLabel = new JLabel(" STATUS:");
		statusLabel.setHorizontalAlignment(SwingConstants.LEFT);
		statusPanel.add(statusLabel);		
		statusPanel.setVisible(true);
		optionsPane.add(statusPanel);
		
		
		//when disconnect button is clicked, users can have the chance to switch from 
		//host to cient.
		disconnectButton.addActionListener(new ActionListener() {
			public synchronized void actionPerformed(ActionEvent e) {
				if (disconnectButton.isEnabled() && connectButtonIsClicked == 1 && hostOption.isSelected()) {
					connectButtonIsClicked = 0;
            		storyContent.portAddress = null;
            		//nullify the server
					((JButton)e.getSource()).setText("Closed ");
            		ipField.setText("localhost");
            		statusLabel.setText("Connection to "+ipField.getText()+" Discontinued, Connect Again?");
            		connectButton.setText("Connect");
            		connectButton.setForeground(Color.black);
            		guestOption.setEnabled(true);
            		disconnectButton.setEnabled(true);
            		storyContent.isConnected = false;
				}
				else if (disconnectButton.isEnabled() && connectButtonIsClicked == 1 && guestOption.isSelected()){
        			//configure client properties
        			storyContent.isHost = false;
        			statusLabel.setText("Connection Discontinued, Connect Again?");
        			((JButton)e.getSource()).setText("Closed ");
        			//ask for refirmation
        			connectButton.setText("Connect");
            		connectButton.setForeground(Color.black);
        			connectButtonIsClicked  = 0;
        			hostOption.setEnabled(true);
        			disconnectButton.setEnabled(true);
        			storyContent.isConnected = false;
				}
			}
		});
		
		
		
		//set up call backs
	    //now connect the Button to the call backs
	    connectButton.addActionListener(new ActionListener() {
			public synchronized void actionPerformed(ActionEvent e){
				//in case the user is a server
            	if (hostOption.isSelected() && connectButtonIsClicked == 0) {
            		storyContent.isHost = true;
            		storyContent.portAddress = portField.getText();
            		//set up the server
            		disconnectButton.setText("Disconnect");
            		java.net.InetAddress i = null;
					try {
						i = java.net.InetAddress.getLocalHost();
					} catch (UnknownHostException e1) {
						e1.printStackTrace();
					}
              		ipField.setText(i.getHostAddress());
            		//display IP address
            		statusLabel.setText("Connecting to "+ i+ " at port "+storyContent.portAddress);
            		JButton button  = (JButton) e.getSource();
            		//ask for re-confirmation
            		button.setText("confirmConnection");
            		button.setForeground(Color.red);
            		connectButtonIsClicked  = 1;
            		guestOption.setEnabled(false);
            		disconnectButton.setEnabled(true);
            	}//Reformation of server
            	else if(hostOption.isSelected() && connectButtonIsClicked == 1){
            		PopUp.dispose();
            		server = storyContent.SetUpServer(); 
            		//set up a server GUI using thread
            		StoryContent serverStory = null;
            		serverStory = new StoryContent(storyContent);
            		storyContent.linkStoryContent = serverStory;
            		//the server does not need a control panel
            		serverStory.guiControl = null; 
            		//set storyContent as a new client that goes with the server
            		storyContent.isHost = false;  
            		storyContent.isConnected = true;  
            		storyContent.ipAddress = "localhost";
            		storyContent.name = nameField.getText();
            		storyContent.IPTextField.setText(storyContent.name+ ", you are connected to IP address: "+storyContent.server.getIPAddress()+" at Port: "+storyContent.portAddress);
            		serverStory.Setup.start();	//set up listening and sending for the server
            		storyContent.Setup.start(); //set up listening and sending for the server's client
            		String TempString = storyContent.status;
        			statusLabel.setText(TempString);
        			if (TempString != null && TempString.compareTo("Connection set up") == 0){	            			
        				PopUp.dispose();
        			}
            	}
            	
            	//in case the user is a client
            	else if(guestOption.isSelected()) {
            		if ( connectButtonIsClicked == 0) {
            			//configure client properties
            			storyContent.isHost = false;
            			String connectOutput = "Connecting to "+ ipField.getText()+ " via port " +portField.getText()+ "..." ;
            			statusLabel.setText(connectOutput);
            			JButton button  = (JButton) e.getSource();
            			disconnectButton.setText("Disconnect");
            			//ask for refirmation
            			button.setText("Click Here Again to Confirm!");
            			button.setForeground(Color.red);
            			connectButtonIsClicked  = 1;
            			hostOption.setEnabled(false);
            			disconnectButton.setEnabled(true);
            		}
            		else {
            			//set up ipAddress and port address
            			storyContent.ipAddress = ipField.getText();
            			System.out.println(ipField.getText() + portField.getText());
            			storyContent.portAddress = portField.getText();
            			storyContent.name = nameField.getText();
                		storyContent.IPTextField.setText(storyContent.name+ ", you are connected to IP address: "+storyContent.ipAddress+" at Port: "+storyContent.portAddress);
            			//configure connection
            			storyContent.isConnected = true;
            			//start client connection
            			storyContent.Setup.start();
            			//close popup
            			PopUp.dispose();
              		} 	           	
            	}
            	else;
			}
        });
	}
	
}