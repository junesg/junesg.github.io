/* Class: GUIMenu.java
 * Description: This Class sets up the menu of the window. Users will be able to either use key board or mouse to select menu items
 * Author: (June) Yuan Shangguan D'13 and Graeson McMahon D'15 
 * CS69 Spring2013
 */

import java.awt.Color;
import java.awt.event.*;
import java.io.IOException;
import javax.swing.*;


/* set up the Menu of the program. 
 * Reference http://docs.oracle.com/javase/tutorial/uiswing/components/menu.html
 */
public class GUIMenu{
	private static final int MENULENGTH = 4;
	private static final int FILEMENULENGTH = 3;
	private static final int GRAPHICMENULENGTH = 3;
	private static final int FEATUREMENULENGTH = 2;
	private StoryContent storyContent = null;
	
	/*
	 * Constructor for GUIMenu. It takes the window and the storyContent references
	 */
	public GUIMenu(final GUIControlPanel guiControl, final JFrame window, StoryContent aStoryContent) {
		storyContent = aStoryContent;  //link Menu to storyContent
		JMenuBar menuBar = new JMenuBar(); //set up the menu bar
		
		//First set up the top layer of menus
        JMenu[] topMenus = new JMenu[MENULENGTH];
        String[] topMenuNames ={"File", "Graphics","Features", "Connections"};
        int[] topMenuKeys = {KeyEvent.VK_F, KeyEvent.VK_G, KeyEvent.VK_F,KeyEvent.VK_C};   //set up menu keys short-cuts
        String[] topMenuDescriptions = { "File menu deals with file related actions", 
			"Features such as search, best and random stories",
			"Edit the Graphics view", "connection to others"};
        String[] topMenuIconSources = {"src/file.png", "src/Edit.png","src/graphLook.png",
			"src/features.png", "src/connect.png"};
        //Append all menus topMenus choices declared
        for (int i = 0; i < MENULENGTH; i++ ) {
        	topMenus[i] = new JMenu(topMenuNames[i]); 
        	topMenus[i].setMnemonic(topMenuKeys[i]);
        	topMenus[i].getAccessibleContext().setAccessibleDescription(topMenuDescriptions[i]);
        	ImageIcon topMenuIcon = new ImageIcon(topMenuIconSources[i]);
        	topMenus[i].setIcon(topMenuIcon);
        	menuBar.add(topMenus[i]);
        }
		
        
        //set up subMenu for File, topMenus[0], the "File" option
        JMenuItem[] FileMenus = new JMenuItem[FILEMENULENGTH];
        String[] FileMenuNames ={"Open","Save","Exit"};
        int[] FileMenuKeys = {KeyEvent.VK_O, KeyEvent.VK_S, KeyEvent.VK_E};
        String[] FileMenuDescriptions = { "Upload a story from your computer", 
			"Download the current story store in a text file", "Exit Program"};
        String[] FileMenuIconSources = {"src/open.png", "src/Download.png","src/exit.png"};
        //append Submenus to the file top item
        for (int i = 0 ; i < FILEMENULENGTH; i ++ ) {
        	ImageIcon FileMenuIcon = new ImageIcon(FileMenuIconSources[i]);
        	FileMenus[i] = new JMenuItem(FileMenuNames[i],FileMenuIcon);
        	FileMenus[i].setMnemonic(FileMenuKeys[i]);
        	FileMenus[i].setAccelerator(KeyStroke.getKeyStroke(FileMenuKeys[i], ActionEvent.CTRL_MASK));
        	topMenus[0].add(FileMenus[i]);
        	FileMenus[i].getAccessibleContext().setAccessibleDescription(FileMenuDescriptions[i]);
        }
		
      	//Import listener for the "Open" option of the file
        FileMenus[0].addActionListener(new ActionListener() {
    		public void actionPerformed(ActionEvent event) {
    			if(storyContent!= null && storyContent.isConnected) {
	    			try {
	    				String filePath = GUIControlPanel.getFilePath();
	    				if (filePath.endsWith(".txt")) {
	    					guiControl.textArea.setText("");
	    					String fileText = StoryNode.getTextFromFile(filePath);
	    					
	    					if (fileText != null) {
	    						storyContent.out.println("IMPORT" + fileText);
	    						guiControl.redoButtons(storyContent.in.readLine());
	    						guiControl.prompt.setText("How would you like to start your story?");
	    						guiControl.setNavigationButtonsEnabled(false);
	    					}
	    					else {
	    						JOptionPane.showMessageDialog(null, 
															  "Invalid input, please use a .txt file which was exported by the program.");
	    					}
	    				}
	    				else {
	    					JOptionPane.showMessageDialog(null, "Only .txt files can be imported.");
	    				}
	    			}
	    			catch (IOException e) {
	    				e.printStackTrace();
	    			}
    			}
    		}
        });
        
        //Export listener for the "Save" option of the file
        FileMenus[1].addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
        		if(storyContent!= null && storyContent.isConnected) {
	        		storyContent.out.println("EXPORT");
	        		try {
	        			StoryNode.writeToFileString
	        		  	(storyContent.in.readLine().replaceAll(GUIControlPanel.CODE, "\n"), GUIControlPanel.getFilePath());
	        		}
	        		catch (IOException e) {
	        			e.printStackTrace();
	        		}
        		}
        	}
        });
        
        //Exit listener for the "Save" option of the file
        FileMenus[2].addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
        		if(storyContent!= null && storyContent.isConnected) {
	        		if (storyContent.linkStoryContent!=null) {
	        			storyContent.linkStoryContent.Setup.interrupt();
	        			window.dispose();
	        		}
	        		else;
					storyContent.Setup.interrupt();
        		}
        	}
        });
		
        //set up subMenu for Graphics, topMenus[2]
        JMenuItem[] GraphicsMenus = new JMenuItem[GRAPHICMENULENGTH];
        String[] GraphicsMenuNames ={"Zoom In","Zoom Out","Assign Colors to Authors of Interest"};
        int[] GraphicsMenuKeys = {KeyEvent.VK_UP, KeyEvent.VK_DOWN, KeyEvent.VK_A};
        String[] GraphicsMenuDescriptions = { "Zoom In Graphics", "Zoom Out Graphics",
			"Adjust Display Graphics Style"};
        String[] GraphicsMenuIconSources = {"src/zoomout.png", "src/zoomin.png","src/style.png"};
		
        //Now append the graphics subMenus to Graphics
        for (int i = 0; i < GRAPHICMENULENGTH; i ++ ) {
        	ImageIcon GraphicsMenuIcon = new ImageIcon(GraphicsMenuIconSources[i]);
        	GraphicsMenus[i] = new JMenuItem(GraphicsMenuNames[i], GraphicsMenuIcon);
        	GraphicsMenus[i].setMnemonic(GraphicsMenuKeys[i]);
        	GraphicsMenus[i].setAccelerator(KeyStroke.getKeyStroke(GraphicsMenuKeys[i], ActionEvent.CTRL_MASK));
        	topMenus[1].add(GraphicsMenus[i]);
        	GraphicsMenus[i].getAccessibleContext().setAccessibleDescription(GraphicsMenuDescriptions[i]);
        }
		
        //Zoom in
        GraphicsMenus[0].addActionListener(new ActionListener() {
  		  	public void actionPerformed(ActionEvent event) {
  		  		if(storyContent!= null && storyContent.isConnected && storyContent.guiControl.drawTreePane!=null) {
  		  			if (storyContent.guiControl.drawTreePane.unitx < 400 && 
  		  				storyContent.guiControl.drawTreePane.unity < 400 && 
  		  				storyContent.guiControl.drawTreePane.radius < 400) {
  		  				storyContent.guiControl.drawTreePane.unitx += 5; 
  		  				storyContent.guiControl.drawTreePane.unity += 5;
  		  				storyContent.guiControl.drawTreePane.radius += 5;
  	        		}
  		  		}
  		  	}
		});  
        
        //Zoom out function
        GraphicsMenus[1].addActionListener(new ActionListener() {
  		  	public void actionPerformed(ActionEvent event) {
  		  		if(storyContent!= null && storyContent.isConnected && storyContent.guiControl.drawTreePane!=null) {
  	        		if (storyContent.guiControl.drawTreePane.unitx > 5 && 
						storyContent.guiControl.drawTreePane.unity >5  && 
						storyContent.guiControl.drawTreePane.radius>5) {
  	        			storyContent.guiControl.drawTreePane.unitx -= 5; 
  	        			storyContent.guiControl.drawTreePane.unity -= 5;
  	        			storyContent.guiControl.drawTreePane.radius -= 5;
  	        		}
  		  		}
  		  	}
		});  
		
        GraphicsMenus[2].addActionListener(new ActionListener() {
  		  	public void actionPerformed(ActionEvent event) {
  		  		if(storyContent!= null && storyContent.isConnected) {
			  		storyContent.out.println("REQUESTAUTHORS");
					try {
						String authorString = storyContent.in.readLine();
						String[] authors = authorString.split(",");
						@SuppressWarnings("unused")
						GUIColorPopUp colorPopUp = new GUIColorPopUp(window, authors, storyContent);
					}
					catch (IOException e) {
						e.printStackTrace();
					} 	
  		  		}
  		  	}
		});  
		
        //set up subMenu for Features, topMenus[3]
        JMenuItem[] FeatureMenus = new JMenuItem[FEATUREMENULENGTH];
        String[] FeatureMenuNames ={"Best Story Recommendation","Random Story"};
        int[] FeatureMenuKeys = {KeyEvent.VK_B, KeyEvent.VK_R};
        String[] FeatureMenuDescriptions = { "Write out the Best story", "Write out a random story"};
		
        for (int i = 0; i < FEATUREMENULENGTH; i ++ ) {
        	FeatureMenus[i] = new JMenuItem(FeatureMenuNames[i],null);
        	FeatureMenus[i].setMnemonic(FeatureMenuKeys[i]);
        	FeatureMenus[i].setAccelerator(KeyStroke.getKeyStroke(FeatureMenuKeys[i], ActionEvent.CTRL_MASK));
        	topMenus[2].add(FeatureMenus[i]);
        	FeatureMenus[i].getAccessibleContext().setAccessibleDescription(FeatureMenuDescriptions[i]);
        }
        
        //Import BestStory Actionlistener
        FeatureMenus[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				if(storyContent!= null && storyContent.isConnected) {
					storyContent.guiControl.textArea.setText("");
					storyContent.out.println("BEST");
					
					try {
						String storyLines = storyContent.in.readLine();
						System.out.println(storyLines);
						String[] storyParsed = storyLines.split("@@@@");
						storyContent.guiControl.textArea.append(storyParsed[0] + " ");
						
						if (storyParsed[0].trim().compareTo("") != 0) {
							storyContent.guiControl.setNavigationButtonsEnabled(false);
						}
						
						storyContent.guiControl.redoButtons(storyParsed[1]);
					}
					catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		});  
		
        //Show IP and Port button
        JButton button = new JButton("  Show IP and Port  ");
        button.setForeground(Color.blue);
		menuBar.add(button);
		//Set up textField
		final JTextField IPTextField = new JTextField(" Connect to Others Via Connections Menu");
		IPTextField.setForeground(Color.blue);
		storyContent.IPTextField = IPTextField;
		IPTextField.setEditable(false);
		IPTextField.setVisible(true);
		
		//add actionlistener to the Show IP and Port button
        button.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
        		if(storyContent!= null && storyContent.isConnected) {
					if(IPTextField.isVisible()) {
						IPTextField.setForeground(Color.white);
						IPTextField.setVisible(false);
					}
					else {
						IPTextField.setForeground(Color.BLUE);
						IPTextField.setVisible(true);
					}
				}
        	}
		});  
		
        menuBar.add(IPTextField);
        menuBar.setVisible(true);
        window.setJMenuBar(menuBar);
        
        //set up connection for topMenus[4]
        final JMenuItem SocketConnect = new JMenuItem("Connect to Others");
        SocketConnect.setMnemonic(KeyEvent.VK_C);
        topMenus[3].add(SocketConnect);
		
        SocketConnect.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if (!storyContent.isConnected) {
        			@SuppressWarnings("unused")
					GUISocket socketWindow = new GUISocket("Connect to Others", window, storyContent);
        			storyContent.isConnected = true;
        		}
        	}
        });	
	}
}
